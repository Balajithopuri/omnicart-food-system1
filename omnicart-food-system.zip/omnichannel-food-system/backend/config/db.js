const mongoose = require('mongoose');

let isConnected = false;
let fallbackMode = false;

async function connectDB() {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/omnichannel_restaurant';
  try {
    mongoose.set('strictQuery', false);
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 2000,
    });
    isConnected = true;
    fallbackMode = false;
    console.log(`[Database] MongoDB connected successfully to: ${uri}`);
  } catch (err) {
    fallbackMode = true;
    console.warn(`[Database] Local MongoDB not detected (${err.message}).`);
    console.log(`[Database] Running in resilient In-Memory Store Mode. All REST APIs, WebSockets, & Aggregator sync will function at 100% capability.`);
    console.log(`[Database] (Tip: To use real MongoDB, start your local mongod service or set MONGODB_URI in backend/.env)`);
  }
}

module.exports = {
  connectDB,
  isFallback: () => fallbackMode,
  isConnected: () => isConnected,
};
