/**
 * Zomato Webhook Payload Adapter
 * Transforms incoming Zomato partner webhook payloads into the normalized UnifiedOrder schema.
 */

function normalizeZomatoOrder(payload) {
  const zomatoOrderId = payload.zomato_order_id || `ZMT-${Math.floor(100000 + Math.random() * 900000)}`;
  const userDetails = payload.user_details || {};
  const dishes = payload.dishes || [];
  const bill = payload.bill_breakdown || {};

  const normalizedItems = dishes.map((dish, idx) => {
    const qty = Number(dish.count) || 1;
    const unitPrice = Number(dish.rate) || 0;
    return {
      menuItemId: dish.dish_code || `dish-zmt-${idx}`,
      name: dish.dish_name || 'Zomato Dish',
      quantity: qty,
      unitPrice: unitPrice,
      totalPrice: unitPrice * qty,
      addOns: dish.customizations || [],
      notes: dish.special_instructions || '',
      kitchenItemStatus: 'PENDING',
    };
  });

  const itemTotal = Number(bill.sub_total) || normalizedItems.reduce((acc, it) => acc + it.totalPrice, 0);
  const taxes = Number(bill.taxes) || +(itemTotal * 0.05).toFixed(2);
  const deliveryFee = Number(bill.delivery_fee) || 40;
  const discount = Number(bill.voucher_discount) || 0;
  const grandTotal = Number(bill.net_paid) || (itemTotal + taxes + deliveryFee - discount);

  // Standard Zomato commission average is 24% on food total
  const commissionRate = 0.24;
  const commissionAmount = +(itemTotal * commissionRate).toFixed(2);
  const netRestaurantPayout = +(grandTotal - commissionAmount).toFixed(2);

  const rider = payload.rider_details ? {
    name: payload.rider_details.rider_name || 'Zomato Delivery Valet',
    phone: payload.rider_details.rider_contact || '+91 91111 22222',
    status: 'ASSIGNED'
  } : {
    name: 'Searching nearby Zomato delivery partner...',
    phone: '',
    status: 'UNASSIGNED'
  };

  return {
    channel: 'ZOMATO',
    channelOrderId: String(zomatoOrderId),
    customer: {
      name: userDetails.name || 'Zomato User',
      phone: userDetails.contact || '+91 99999 00000',
      address: userDetails.delivery_location || 'Customer Delivery Location (Zomato)',
    },
    items: normalizedItems,
    financials: {
      itemTotal,
      taxes,
      deliveryFee,
      discount,
      grandTotal,
      platformCommissionRate: commissionRate,
      platformCommissionAmount: commissionAmount,
      netRestaurantPayout,
    },
    status: 'PLACED',
    prepTimeMinutes: payload.prep_time_estimate || 20,
    rider,
    timeline: [
      {
        status: 'PLACED',
        timestamp: new Date(),
        actor: 'Zomato Aggregator Webhook',
        notes: `Order received via Zomato API (ID: ${zomatoOrderId})`
      }
    ]
  };
}

module.exports = {
  normalizeZomatoOrder
};
