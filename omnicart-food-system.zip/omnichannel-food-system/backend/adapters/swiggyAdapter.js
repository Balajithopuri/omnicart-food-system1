/**
 * Swiggy Webhook Payload Adapter
 * Transforms incoming Swiggy partner webhook payloads into the normalized UnifiedOrder schema.
 */

function normalizeSwiggyOrder(payload) {
  const swiggyOrderId = payload.order_id || `SWG-${Math.floor(100000 + Math.random() * 900000)}`;
  const customer = payload.customer || {};
  const cart = payload.cart || {};
  const items = cart.items || [];
  const pricing = cart.pricing || {};

  const normalizedItems = items.map((item, idx) => {
    const qty = Number(item.quantity) || 1;
    const unitPrice = Number(item.price) || 0;
    return {
      menuItemId: item.item_id || `item-swg-${idx}`,
      name: item.name || 'Swiggy Item',
      quantity: qty,
      unitPrice: unitPrice,
      totalPrice: unitPrice * qty,
      addOns: item.add_ons || [],
      notes: item.instructions || '',
      kitchenItemStatus: 'PENDING',
    };
  });

  const itemTotal = Number(pricing.item_total) || normalizedItems.reduce((acc, it) => acc + it.totalPrice, 0);
  const taxes = Number(pricing.gst) || +(itemTotal * 0.05).toFixed(2);
  const deliveryFee = Number(pricing.delivery_charge) || 35;
  const discount = Number(pricing.discount) || 0;
  const grandTotal = Number(pricing.total_amount) || (itemTotal + taxes + deliveryFee - discount);

  // Standard Swiggy commission average is 22% on food total
  const commissionRate = 0.22;
  const commissionAmount = +(itemTotal * commissionRate).toFixed(2);
  const netRestaurantPayout = +(grandTotal - commissionAmount).toFixed(2);

  const rider = payload.delivery_partner ? {
    name: payload.delivery_partner.name || 'Swiggy Fleet Executive',
    phone: payload.delivery_partner.phone || '+91 90000 11111',
    status: 'ASSIGNED'
  } : {
    name: 'Searching nearby Swiggy delivery partner...',
    phone: '',
    status: 'UNASSIGNED'
  };

  return {
    channel: 'SWIGGY',
    channelOrderId: String(swiggyOrderId),
    customer: {
      name: customer.customer_name || 'Swiggy User',
      phone: customer.customer_phone || '+91 98765 00000',
      address: customer.delivery_address || 'Customer Delivery Address (Swiggy)',
    },
    items: normalizedItems,
    financials: {
      itemTotal,
      taxes,
      deliveryFee,
      discount,
      grandTotal,
      platformCommissionRate: commissionRate,
      platformCommissionAmount: commissionAmount,
      netRestaurantPayout,
    },
    status: 'PLACED',
    prepTimeMinutes: payload.estimated_prep_minutes || 20,
    rider,
    timeline: [
      {
        status: 'PLACED',
        timestamp: new Date(),
        actor: 'Swiggy Aggregator Webhook',
        notes: `Order received via Swiggy API (ID: ${swiggyOrderId})`
      }
    ]
  };
}

module.exports = {
  normalizeSwiggyOrder
};
