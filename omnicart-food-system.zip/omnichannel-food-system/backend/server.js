const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const dotenv = require('dotenv');

dotenv.config();

const { connectDB } = require('./config/db');
const aggregatorSyncService = require('./services/aggregatorSyncService');

const app = express();
const server = http.createServer(app);

// Configure Socket.io with permissive CORS for local dev
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
  },
});

// Pass Socket.io to sync service
aggregatorSyncService.setSocketIO(io);

// Middleware
app.use(cors());
app.use(express.json());

// Socket.io connection handling
io.on('connection', (socket) => {
  console.log(`[WebSocket] Client connected: ${socket.id}`);

  socket.on('join_terminal', (role) => {
    console.log(`[WebSocket] Client ${socket.id} joined channel: ${role}`);
    socket.join(role);
  });

  socket.on('disconnect', () => {
    console.log(`[WebSocket] Client disconnected: ${socket.id}`);
  });
});

// Mount Routes
app.use('/api/orders', require('./routes/orderRoutes')(io));
app.use('/api/menu', require('./routes/menuRoutes')(io));
app.use('/api/webhooks', require('./routes/webhookRoutes')(io));
app.use('/api/simulator', require('./routes/simulatorRoutes')(io));
app.use('/api/analytics', require('./routes/analyticsRoutes')());
app.use('/api/hub', require('./routes/multiOrderRoutes')(io));

// Health & System Info
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    system: 'Omnichannel Restaurant & Aggregator Engine',
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString()
  });
});

// Serve Frontend static assets in production if dist exists
const path = require('path');
const fs = require('fs');
const frontendDist = path.join(__dirname, '../frontend/dist');

if (fs.existsSync(frontendDist)) {
  console.log(`[Static] Serving production frontend build from: ${frontendDist}`);
  app.use(express.static(frontendDist));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api') || req.path.startsWith('/socket.io')) return next();
    res.sendFile(path.join(frontendDist, 'index.html'));
  });
}

// Port configuration
const PORT = process.env.PORT || 5000;

async function startServer() {
  await connectDB();
  server.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`🚀 Omnichannel Food & Restaurant System Backend Running`);
    console.log(`📡 HTTP Server & WebSockets: http://localhost:${PORT}`);
    console.log(`🔗 Swiggy Webhook Gateway:  http://localhost:${PORT}/api/webhooks/swiggy`);
    console.log(`🔗 Zomato Webhook Gateway:  http://localhost:${PORT}/api/webhooks/zomato`);
    console.log(`=======================================================`);
  });
}

startServer();
