const express = require('express');
const router = express.Router();
const Store = require('../models/store');
const { normalizeSwiggyOrder } = require('../adapters/swiggyAdapter');
const { normalizeZomatoOrder } = require('../adapters/zomatoAdapter');

module.exports = (io) => {
  // POST /api/webhooks/swiggy - Partner Ingestion
  router.post('/swiggy', async (req, res) => {
    const startTime = Date.now();
    try {
      const swiggyPayload = req.body;
      console.log('[Webhook Ingest] Received Swiggy Webhook payload:', JSON.stringify(swiggyPayload).slice(0, 150) + '...');

      // 1. Adapter Normalization
      const normalizedOrder = normalizeSwiggyOrder(swiggyPayload);

      // 2. Persist Unified Order
      const newOrder = await Store.createOrder(normalizedOrder);

      // 3. Audit Log
      await Store.logAggregatorEvent({
        source: 'SWIGGY',
        eventType: 'ORDER_PLACED',
        channelOrderId: normalizedOrder.channelOrderId,
        payload: swiggyPayload,
        normalizedUnifiedOrder: newOrder,
        status: 'PROCESSED_SUCCESSFULLY',
        processingLatencyMs: Date.now() - startTime
      });

      // 4. Real-time push to POS and Kitchen screens
      io.emit('new_order', {
        order: newOrder,
        soundAlert: true,
        source: 'SWIGGY',
        message: `🟠 New Swiggy Order #${newOrder.channelOrderId} (${newOrder.customer.name})`
      });

      // 5. Standard Swiggy Partner ACK
      res.status(200).json({
        status: 'success',
        code: 200,
        swiggy_order_id: normalizedOrder.channelOrderId,
        internal_order_id: newOrder.orderNumber,
        message: 'Order received and queued in Restaurant POS',
        ack_timestamp: new Date().toISOString()
      });
    } catch (err) {
      console.error('[Webhook Ingest Error - Swiggy]:', err);
      res.status(500).json({ status: 'error', error: err.message });
    }
  });

  // POST /api/webhooks/zomato - Partner Ingestion
  router.post('/zomato', async (req, res) => {
    const startTime = Date.now();
    try {
      const zomatoPayload = req.body;
      console.log('[Webhook Ingest] Received Zomato Webhook payload:', JSON.stringify(zomatoPayload).slice(0, 150) + '...');

      // 1. Adapter Normalization
      const normalizedOrder = normalizeZomatoOrder(zomatoPayload);

      // 2. Persist Unified Order
      const newOrder = await Store.createOrder(normalizedOrder);

      // 3. Audit Log
      await Store.logAggregatorEvent({
        source: 'ZOMATO',
        eventType: 'ORDER_PLACED',
        channelOrderId: normalizedOrder.channelOrderId,
        payload: zomatoPayload,
        normalizedUnifiedOrder: newOrder,
        status: 'PROCESSED_SUCCESSFULLY',
        processingLatencyMs: Date.now() - startTime
      });

      // 4. Real-time push to POS and Kitchen screens
      io.emit('new_order', {
        order: newOrder,
        soundAlert: true,
        source: 'ZOMATO',
        message: `🔴 New Zomato Order #${newOrder.channelOrderId} (${newOrder.customer.name})`
      });

      // 5. Standard Zomato Partner ACK
      res.status(200).json({
        status: 'OK',
        response_code: 200,
        zomato_order_id: normalizedOrder.channelOrderId,
        outlet_order_id: newOrder.orderNumber,
        message: 'Order pushed to restaurant POS successfully',
        timestamp: new Date().toISOString()
      });
    } catch (err) {
      console.error('[Webhook Ingest Error - Zomato]:', err);
      res.status(500).json({ status: 'FAIL', error: err.message });
    }
  });

  return router;
};
