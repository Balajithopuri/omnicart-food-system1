const express = require('express');
const router = express.Router();
const Store = require('../models/store');
const aggregatorSyncService = require('../services/aggregatorSyncService');

module.exports = (io) => {
  // GET all menu items
  router.get('/', async (req, res) => {
    try {
      const items = await Store.getMenuItems();
      res.json({ success: true, count: items.length, items });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // PUT toggle availability (86-ing an item)
  router.put('/:id/toggle', async (req, res) => {
    try {
      const { id } = req.params;
      const { isAvailable } = req.body;

      const item = await Store.getMenuItemById(id);
      if (!item) return res.status(404).json({ success: false, error: 'Menu item not found' });

      const updatedItem = await Store.toggleMenuItemAvailability(id, isAvailable);

      // Trigger multi-platform 86-ing sync to Swiggy & Zomato
      await aggregatorSyncService.syncInventoryAvailability(updatedItem, isAvailable);

      res.json({ 
        success: true, 
        item: updatedItem,
        message: `Item availability synced across Direct, Swiggy, and Zomato catalogs`
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  return router;
};
