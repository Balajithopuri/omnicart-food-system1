const express = require('express');
const router = express.Router();
const MultiStore = require('../models/multiStore');

module.exports = (io) => {
  // GET all India geographic zones (Top to Bottom, West, East, Central)
  router.get('/zones', (req, res) => {
    try {
      const zones = MultiStore.getZones();
      res.json({ success: true, count: zones.length, zones });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET all Pan-India cities
  router.get('/cities', (req, res) => {
    try {
      const cities = MultiStore.getCities();
      res.json({ success: true, count: cities.length, cities });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET hub restaurants & catalogs (filtered by city, zone, or custom town/village query)
  router.get('/restaurants', (req, res) => {
    try {
      const { city, zone, q } = req.query;
      const queryParam = q || city || null;
      const zoneParam = zone || 'ALL';
      const restaurants = MultiStore.getHubRestaurants(queryParam, zoneParam);
      res.json({ success: true, count: restaurants.length, restaurants });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET all multi-store orders
  router.get('/orders', (req, res) => {
    try {
      const orders = MultiStore.getMultiOrders();
      res.json({ success: true, count: orders.length, orders });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET single multi-store order
  router.get('/orders/:id', (req, res) => {
    try {
      const order = MultiStore.getMultiOrderById(req.params.id);
      if (!order) return res.status(404).json({ success: false, error: 'Multi-order not found' });
      res.json({ success: true, order });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // POST create multi-restaurant master order
  router.post('/orders', (req, res) => {
    try {
      const { customer, items } = req.body;
      if (!customer || !items || !items.length) {
        return res.status(400).json({ success: false, error: 'Customer and items are required' });
      }

      // Group items by restaurant
      const restaurantMap = {};
      items.forEach(it => {
        const rid = it.restaurantId || 'res-default';
        if (!restaurantMap[rid]) {
          restaurantMap[rid] = {
            restaurantId: rid,
            restaurantName: it.restaurantName || 'Hub Partner',
            items: [],
            subtotal: 0,
            status: 'PREPARING',
            prepTimeMinutes: 15
          };
        }
        restaurantMap[rid].items.push(it);
        restaurantMap[rid].subtotal += (it.price * it.quantity);
      });

      const subOrders = Object.values(restaurantMap);
      const uniqueRestaurantCount = subOrders.length;

      const itemsTotal = items.reduce((acc, it) => acc + (it.price * it.quantity), 0);
      const taxes = +(itemsTotal * 0.05).toFixed(2);

      // What Swiggy / Zomato would charge: ₹40 delivery fee for EACH restaurant separately
      const swiggyDeliveryEquivalent = uniqueRestaurantCount * 40;

      // OmniCart Smart Multi-Stop Fee: Base ₹35 + ₹15 per extra stop
      const multiStopDeliveryFee = 35 + ((uniqueRestaurantCount - 1) * 15);
      const deliverySavings = swiggyDeliveryEquivalent - multiStopDeliveryFee;

      const grandTotal = +(itemsTotal + taxes + multiStopDeliveryFee).toFixed(2);

      // Construct Multi-Stop Route
      const stops = subOrders.map((sub, idx) => {
        const outlet = MultiStore.getRestaurantById(sub.restaurantId);
        const outletLoc = outlet ? outlet.hubLocation : (req.body.clusterName || 'Regional Food Hub');
        return {
          sequence: idx + 1,
          type: 'PICKUP',
          restaurantId: sub.restaurantId,
          title: `Pickup #${idx + 1}: ${sub.restaurantName}`,
          location: outletLoc,
          status: idx === 0 ? 'ARRIVED_AT_STOP' : 'PENDING',
          itemsCount: sub.items.length
        };
      });

      // Final stop: customer doorstep
      stops.push({
        sequence: stops.length + 1,
        type: 'DROPOFF',
        title: `Final Stop: Deliver to ${customer.name}`,
        location: customer.address || 'Customer Delivery Address',
        status: 'PENDING',
        itemsCount: items.length
      });

      const multiStopRoute = {
        totalStops: stops.length,
        currentStopIndex: 0,
        stops,
        rider: {
          name: 'Ramesh Kumar (OmniCart Multi-Rider)',
          phone: '+91 98450 99887',
          vehicle: 'Honda Activa (KA-04-EK-9102)',
          bagType: 'Dual-Zone Thermal Bag (Hot & Chilled Compartments)'
        }
      };

      const orderCluster = req.body.clusterName || (stops[0] ? stops[0].location : 'Regional Hub');
      const orderData = {
        clusterName: orderCluster,
        customer: {
          name: customer.name || 'Group Customer',
          phone: customer.phone || '+91 99999 11111',
          address: customer.address || 'Direct Address'
        },
        subOrders,
        multiStopRoute,
        financials: {
          itemsTotal,
          taxes,
          multiStopDeliveryFee,
          swiggyDeliveryEquivalent,
          deliverySavings,
          grandTotal
        }
      };

      const newOrder = MultiStore.createMultiOrder(orderData);

      io.emit('new_multi_order', {
        order: newOrder,
        message: `🛒 New Multi-Restaurant Order #${newOrder.orderNumber} placed across ${uniqueRestaurantCount} stores!`
      });

      res.status(201).json({ success: true, order: newOrder });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // PUT advance rider to next stop
  router.put('/orders/:id/advance-stop', (req, res) => {
    try {
      const order = MultiStore.advanceRouteStop(req.params.id);
      if (!order) return res.status(404).json({ success: false, error: 'Order not found' });

      io.emit('multi_route_updated', {
        orderId: order.id,
        orderNumber: order.orderNumber,
        routeProgress: order.routeProgress,
        status: order.status,
        order
      });

      res.json({ success: true, order });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  return router;
};
