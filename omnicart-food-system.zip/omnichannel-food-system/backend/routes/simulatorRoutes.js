const express = require('express');
const router = express.Router();
const Store = require('../models/store');
const { normalizeSwiggyOrder } = require('../adapters/swiggyAdapter');
const { normalizeZomatoOrder } = require('../adapters/zomatoAdapter');

const CUSTOMERS = [
  { name: 'Arjun Kapoor', phone: '+91 98451 22334', address: 'Flat 1204, Brigade Gateway, Malleshwaram' },
  { name: 'Ananya Deshmukh', phone: '+91 97312 88990', address: 'House 45, 12th Main, Koramangala 4th Block' },
  { name: 'Rohan Sen', phone: '+91 99001 55667', address: 'Tower 3, Divyasree Republic of Whitefield' },
  { name: 'Kavita Nair', phone: '+91 98860 33445', address: 'Plot 72, HSR Layout Sector 2' },
  { name: 'Vikram Joshi', phone: '+91 96112 44778', address: 'Villa 18, Adarsh Palm Retreat, Bellandur' }
];

const SWIGGY_RIDERS = [
  { name: 'Sunil Gowda (Swiggy Fleet)', phone: '+91 98440 11223' },
  { name: 'Manish Rawat (Swiggy Fleet)', phone: '+91 97330 44556' },
  { name: 'Deepak Rao (Swiggy Fleet)', phone: '+91 99110 77889' }
];

const ZOMATO_RIDERS = [
  { name: 'Ajay Solanki (Zomato Valet)', phone: '+91 98220 33441' },
  { name: 'Pradeep Yadav (Zomato Valet)', phone: '+91 97110 55662' },
  { name: 'Sanjay Murthy (Zomato Valet)', phone: '+91 99440 88993' }
];

module.exports = (io) => {
  // POST /api/simulator/trigger-order
  router.post('/trigger-order', async (req, res) => {
    try {
      const { channel = 'SWIGGY', customerName } = req.body;
      const menu = await Store.getMenuItems();
      const availableItems = menu.filter(m => m.isAvailable);

      if (availableItems.length === 0) {
        return res.status(400).json({ success: false, error: 'No menu items are currently available' });
      }

      // Pick 1 to 3 random items
      const numItems = Math.min(Math.floor(Math.random() * 2) + 1, availableItems.length);
      const shuffled = [...availableItems].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, numItems);

      const customer = customerName 
        ? { name: customerName, phone: '+91 98765 11223', address: 'Simulated Test Address' }
        : CUSTOMERS[Math.floor(Math.random() * CUSTOMERS.length)];

      let rawPayload = null;
      let normalizedOrder = null;

      if (channel.toUpperCase() === 'SWIGGY') {
        const orderId = `SWG-${Math.floor(100000 + Math.random() * 900000)}`;
        const rider = SWIGGY_RIDERS[Math.floor(Math.random() * SWIGGY_RIDERS.length)];
        
        let itemTotal = 0;
        const swiggyItems = selected.map(item => {
          const qty = Math.floor(Math.random() * 2) + 1;
          const price = item.price;
          itemTotal += price * qty;
          return {
            item_id: item.swiggyItemId || item.id,
            name: item.name,
            quantity: qty,
            price: price,
            add_ons: item.addOns && item.addOns.length ? [item.addOns[0].name] : [],
            instructions: 'Less spicy please'
          };
        });

        rawPayload = {
          order_id: orderId,
          restaurant_id: 'RES_BLR_09',
          customer: {
            customer_name: customer.name,
            customer_phone: customer.phone,
            delivery_address: customer.address
          },
          cart: {
            items: swiggyItems,
            pricing: {
              item_total: itemTotal,
              gst: +(itemTotal * 0.05).toFixed(2),
              delivery_charge: 35,
              total_amount: +(itemTotal + (itemTotal * 0.05) + 35).toFixed(2)
            }
          },
          delivery_partner: rider,
          estimated_prep_minutes: 20
        };

        normalizedOrder = normalizeSwiggyOrder(rawPayload);
      } else {
        // Zomato
        const orderId = `ZMT-${Math.floor(100000 + Math.random() * 900000)}`;
        const rider = ZOMATO_RIDERS[Math.floor(Math.random() * ZOMATO_RIDERS.length)];

        let itemTotal = 0;
        const zomatoDishes = selected.map(item => {
          const qty = Math.floor(Math.random() * 2) + 1;
          const rate = item.price;
          itemTotal += rate * qty;
          return {
            dish_code: item.zomatoItemId || item.id,
            dish_name: item.name,
            count: qty,
            rate: rate,
            customizations: item.addOns && item.addOns.length ? [item.addOns[0].name] : [],
            special_instructions: 'Pack extra cutlery'
          };
        });

        rawPayload = {
          zomato_order_id: orderId,
          outlet_code: 'OUTLET_007',
          user_details: {
            name: customer.name,
            contact: customer.phone,
            delivery_location: customer.address
          },
          dishes: zomatoDishes,
          bill_breakdown: {
            sub_total: itemTotal,
            taxes: +(itemTotal * 0.05).toFixed(2),
            delivery_fee: 40,
            voucher_discount: 0,
            net_paid: +(itemTotal + (itemTotal * 0.05) + 40).toFixed(2)
          },
          rider_details: {
            rider_name: rider.name,
            rider_contact: rider.phone
          },
          prep_time_estimate: 20
        };

        normalizedOrder = normalizeZomatoOrder(rawPayload);
      }

      // Save order
      const newOrder = await Store.createOrder(normalizedOrder);

      // Save audit log
      await Store.logAggregatorEvent({
        source: channel.toUpperCase(),
        eventType: 'SIMULATED_ORDER_INGESTED',
        channelOrderId: normalizedOrder.channelOrderId,
        payload: rawPayload,
        normalizedUnifiedOrder: newOrder,
        status: 'SIMULATED_SUCCESS',
        processingLatencyMs: 18
      });

      // Realtime alert
      io.emit('new_order', {
        order: newOrder,
        soundAlert: true,
        source: channel.toUpperCase(),
        message: `⚡ Simulated ${channel.toUpperCase()} Order #${newOrder.channelOrderId} Ingested!`
      });

      res.status(201).json({
        success: true,
        channel: channel.toUpperCase(),
        rawPayload,
        normalizedOrder: newOrder,
        message: `Simulated ${channel.toUpperCase()} webhook injected into POS queue`
      });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // POST /api/simulator/trigger-rider-arrival
  router.post('/trigger-rider-arrival', async (req, res) => {
    try {
      const { orderId } = req.body;
      const order = await Store.getOrderById(orderId);
      if (!order) return res.status(404).json({ success: false, error: 'Order not found' });

      order.rider = {
        ...order.rider,
        status: 'ARRIVED_AT_STORE'
      };

      await Store.updateOrderStatus(order.id, order.status, `${order.channel}_RIDER`, {
        notes: `Rider ${order.rider.name} has arrived at restaurant front counter`
      });

      io.emit('rider_status_updated', {
        orderId: order.id,
        orderNumber: order.orderNumber,
        rider: order.rider,
        channel: order.channel,
        message: `🛵 ${order.channel} Rider arrived for order ${order.orderNumber}`
      });

      res.json({ success: true, order });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET /api/simulator/logs
  router.get('/logs', async (req, res) => {
    try {
      const logs = await Store.getAggregatorLogs();
      res.json({ success: true, count: logs.length, logs });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  return router;
};
