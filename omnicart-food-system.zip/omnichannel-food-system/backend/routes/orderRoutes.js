const express = require('express');
const router = express.Router();
const Store = require('../models/store');
const aggregatorSyncService = require('../services/aggregatorSyncService');

module.exports = (io) => {
  // GET all orders
  router.get('/', async (req, res) => {
    try {
      const { channel, status } = req.query;
      let orders = await Store.getOrders();
      if (channel) {
        orders = orders.filter(o => o.channel.toUpperCase() === channel.toUpperCase());
      }
      if (status) {
        orders = orders.filter(o => o.status.toUpperCase() === status.toUpperCase());
      }
      res.json({ success: true, count: orders.length, orders });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET order by ID
  router.get('/:id', async (req, res) => {
    try {
      const order = await Store.getOrderById(req.params.id);
      if (!order) return res.status(404).json({ success: false, error: 'Order not found' });
      res.json({ success: true, order });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // POST create direct customer order
  router.post('/', async (req, res) => {
    try {
      const { customer, items, orderType = 'DELIVERY' } = req.body;
      if (!customer || !items || !items.length) {
        return res.status(400).json({ success: false, error: 'Customer information and items are required' });
      }

      const isPickup = orderType.toUpperCase() === 'PICKUP';
      const itemTotal = items.reduce((sum, it) => sum + (it.unitPrice * it.quantity), 0);
      const taxes = +(itemTotal * 0.05).toFixed(2);
      const deliveryFee = isPickup ? 0 : 30; // ₹0 delivery fee for customer takeaway/pickup!
      const grandTotal = +(itemTotal + taxes + deliveryFee).toFixed(2);
      const pickupCode = isPickup ? `PK-${Math.floor(100 + Math.random() * 900)}` : null;

      const orderData = {
        channel: 'DIRECT',
        orderType: isPickup ? 'PICKUP' : 'DELIVERY',
        pickupCode,
        channelOrderId: `WEB-${Math.floor(100000 + Math.random() * 900000)}`,
        customer: {
          name: customer.name || 'Online Customer',
          phone: customer.phone || '+91 98000 00000',
          address: isPickup 
            ? 'Store Pickup Counter (Spice Garden Bistro)' 
            : (customer.address || 'Direct Delivery Address'),
        },
        items: items.map(it => ({
          menuItemId: it.menuItemId || it.id,
          name: it.name,
          quantity: it.quantity,
          unitPrice: it.unitPrice,
          totalPrice: it.unitPrice * it.quantity,
          addOns: it.addOns || [],
          notes: it.notes || '',
          kitchenItemStatus: 'PENDING'
        })),
        financials: {
          itemTotal,
          taxes,
          deliveryFee,
          discount: 0,
          grandTotal,
          platformCommissionRate: 0,
          platformCommissionAmount: 0,
          netRestaurantPayout: grandTotal, // 100% direct revenue!
        },
        status: 'PLACED',
        prepTimeMinutes: isPickup ? 15 : 20,
        rider: isPickup ? {
          name: `Customer Self-Pickup [Code: ${pickupCode}]`,
          phone: customer.phone || '',
          status: 'CUSTOMER_PICKUP'
        } : {
          name: 'Restaurant In-house Rider',
          phone: '+91 97777 88888',
          status: 'ASSIGNED'
        }
      };

      const newOrder = await Store.createOrder(orderData);

      // Broadcast real-time event to POS & KDS
      io.emit('new_order', {
        order: newOrder,
        soundAlert: true,
        source: 'DIRECT',
        message: `New Direct Order #${newOrder.orderNumber} received!`
      });

      res.status(201).json({ success: true, order: newOrder });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // PUT update order status (Cashier Accept, KDS Bump, Ready, Out for delivery)
  router.put('/:id/status', async (req, res) => {
    try {
      const { status, prepTimeMinutes, actor, rider, notes } = req.body;
      const order = await Store.getOrderById(req.params.id);
      if (!order) return res.status(404).json({ success: false, error: 'Order not found' });

      const updatedOrder = await Store.updateOrderStatus(order.id, status, actor || 'POS_STAFF', {
        prepTimeMinutes,
        rider,
        notes
      });

      // Synchronize with external aggregator (Swiggy / Zomato)
      await aggregatorSyncService.notifyStatusUpdate(updatedOrder, status, { prepTimeMinutes });

      // Broadcast state update to all UI screens
      io.emit('order_status_updated', {
        orderId: updatedOrder.id,
        orderNumber: updatedOrder.orderNumber,
        newStatus: status,
        order: updatedOrder
      });

      res.json({ success: true, order: updatedOrder });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // PUT update single item status in Kitchen (KDS item-level strikeout)
  router.put('/:id/item-status', async (req, res) => {
    try {
      const { itemIndex, itemStatus } = req.body;
      const order = await Store.getOrderById(req.params.id);
      if (!order || !order.items[itemIndex]) {
        return res.status(404).json({ success: false, error: 'Item not found in order' });
      }

      order.items[itemIndex].kitchenItemStatus = itemStatus;
      
      // If all items are READY, automatically suggest marking order READY
      const allReady = order.items.every(it => it.kitchenItemStatus === 'READY');

      io.emit('kds_item_updated', {
        orderId: order.id,
        itemIndex,
        itemStatus,
        allReady
      });

      res.json({ success: true, order, allReady });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  return router;
};
