const express = require('express');
const router = express.Router();
const Store = require('../models/store');

module.exports = () => {
  router.get('/summary', async (req, res) => {
    try {
      const orders = await Store.getOrders();

      const summary = {
        totalOrders: orders.length,
        grossRevenue: 0,
        totalCommissionPaid: 0,
        netRestaurantPayout: 0,
        channelMetrics: {
          DIRECT: { count: 0, gross: 0, commission: 0, net: 0, commissionRate: '0%' },
          SWIGGY: { count: 0, gross: 0, commission: 0, net: 0, commissionRate: '22%' },
          ZOMATO: { count: 0, gross: 0, commission: 0, net: 0, commissionRate: '24%' }
        },
        statusCounts: {
          PLACED: 0,
          ACCEPTED: 0,
          IN_KITCHEN: 0,
          FOOD_READY: 0,
          OUT_FOR_DELIVERY: 0,
          DELIVERED: 0,
          CANCELLED: 0
        },
        itemFrequency: {}
      };

      orders.forEach(ord => {
        const grand = ord.financials?.grandTotal || 0;
        const comm = ord.financials?.platformCommissionAmount || 0;
        const net = ord.financials?.netRestaurantPayout || grand;
        const channel = ord.channel || 'DIRECT';

        summary.grossRevenue += grand;
        summary.totalCommissionPaid += comm;
        summary.netRestaurantPayout += net;

        if (summary.channelMetrics[channel]) {
          summary.channelMetrics[channel].count += 1;
          summary.channelMetrics[channel].gross += grand;
          summary.channelMetrics[channel].commission += comm;
          summary.channelMetrics[channel].net += net;
        }

        if (summary.statusCounts[ord.status] !== undefined) {
          summary.statusCounts[ord.status] += 1;
        }

        if (ord.items && Array.isArray(ord.items)) {
          ord.items.forEach(it => {
            summary.itemFrequency[it.name] = (summary.itemFrequency[it.name] || 0) + it.quantity;
          });
        }
      });

      // Format round numbers
      summary.grossRevenue = +summary.grossRevenue.toFixed(2);
      summary.totalCommissionPaid = +summary.totalCommissionPaid.toFixed(2);
      summary.netRestaurantPayout = +summary.netRestaurantPayout.toFixed(2);

      Object.keys(summary.channelMetrics).forEach(ch => {
        summary.channelMetrics[ch].gross = +summary.channelMetrics[ch].gross.toFixed(2);
        summary.channelMetrics[ch].commission = +summary.channelMetrics[ch].commission.toFixed(2);
        summary.channelMetrics[ch].net = +summary.channelMetrics[ch].net.toFixed(2);
      });

      // Top 5 dishes
      summary.topDishes = Object.entries(summary.itemFrequency)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([name, count]) => ({ name, count }));

      res.json({ success: true, summary });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  return router;
};
