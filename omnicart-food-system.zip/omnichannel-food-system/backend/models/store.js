const { v4: uuidv4 } = require('uuid');
const { isFallback } = require('../config/db');
const { MenuItemModel, OrderModel, AggregatorLogModel } = require('./schemas');

// Initial seed menu data
const INITIAL_MENU = [
  {
    id: 'm1',
    name: 'Butter Chicken Masala',
    category: 'Main Course',
    description: 'Tender tandoori chicken cooked in rich, creamy tomato and butter gravy.',
    price: 340,
    isVeg: false,
    isAvailable: true,
    swiggyItemId: 'SWG_ITM_101',
    zomatoItemId: 'ZMT_DSH_201',
    preparationTimeMinutes: 18,
    imageUrl: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=400&q=80',
    addOns: [{ name: 'Extra Butter', price: 30 }, { name: 'Boneless Upgrade', price: 50 }]
  },
  {
    id: 'm2',
    name: 'Paneer Butter Masala',
    category: 'Main Course',
    description: 'Soft cottage cheese cubes simmered in aromatic velvet makhani sauce.',
    price: 280,
    isVeg: true,
    isAvailable: true,
    swiggyItemId: 'SWG_ITM_102',
    zomatoItemId: 'ZMT_DSH_202',
    preparationTimeMinutes: 15,
    imageUrl: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=400&q=80',
    addOns: [{ name: 'Extra Paneer', price: 60 }]
  },
  {
    id: 'm3',
    name: 'Hyderabadi Chicken Dum Biryani',
    category: 'Breads & Rice',
    description: 'Fragrant basmati rice cooked on dum with marinated spiced chicken and saffron.',
    price: 320,
    isVeg: false,
    isAvailable: true,
    swiggyItemId: 'SWG_ITM_103',
    zomatoItemId: 'ZMT_DSH_203',
    preparationTimeMinutes: 20,
    imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=400&q=80',
    addOns: [{ name: 'Extra Mirchi Ka Salan', price: 40 }, { name: 'Raita Cup', price: 30 }]
  },
  {
    id: 'm4',
    name: 'Tandoori Chicken Tikka (6 Pcs)',
    category: 'Starters',
    description: 'Smoky spiced chicken skewers charred to perfection in traditional clay oven.',
    price: 290,
    isVeg: false,
    isAvailable: true,
    swiggyItemId: 'SWG_ITM_104',
    zomatoItemId: 'ZMT_DSH_204',
    preparationTimeMinutes: 15,
    imageUrl: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=400&q=80',
    addOns: [{ name: 'Mint Chutney Double', price: 20 }]
  },
  {
    id: 'm5',
    name: 'Crispy Corn Salt & Pepper',
    category: 'Starters',
    description: 'Golden fried sweet corn tossed with bell peppers, spring onions, and cracked pepper.',
    price: 220,
    isVeg: true,
    isAvailable: true,
    swiggyItemId: 'SWG_ITM_105',
    zomatoItemId: 'ZMT_DSH_205',
    preparationTimeMinutes: 12,
    imageUrl: 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=400&q=80',
    addOns: []
  },
  {
    id: 'm6',
    name: 'Garlic Butter Naan',
    category: 'Breads & Rice',
    description: 'Clay-oven baked flatbread infused with roasted garlic and brushed with clarified butter.',
    price: 65,
    isVeg: true,
    isAvailable: true,
    swiggyItemId: 'SWG_ITM_106',
    zomatoItemId: 'ZMT_DSH_206',
    preparationTimeMinutes: 8,
    imageUrl: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=400&q=80',
    addOns: [{ name: 'Cheese Stuffed', price: 45 }]
  },
  {
    id: 'm7',
    name: 'Gulab Jamun with Rabri (2 Pcs)',
    category: 'Desserts',
    description: 'Warm khoya dumplings steeped in rose cardamom syrup, served over chilled rabri.',
    price: 140,
    isVeg: true,
    isAvailable: true,
    swiggyItemId: 'SWG_ITM_107',
    zomatoItemId: 'ZMT_DSH_207',
    preparationTimeMinutes: 5,
    imageUrl: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=400&q=80',
    addOns: []
  },
  {
    id: 'm8',
    name: 'Kesar Mango Lassi',
    category: 'Beverages',
    description: 'Thick, creamy yogurt churned with real Alphonso mango pulp and saffron strands.',
    price: 110,
    isVeg: true,
    isAvailable: true,
    swiggyItemId: 'SWG_ITM_108',
    zomatoItemId: 'ZMT_DSH_208',
    preparationTimeMinutes: 5,
    imageUrl: 'https://images.unsplash.com/photo-1527661591475-527312dd65f5?auto=format&fit=crop&w=400&q=80',
    addOns: [{ name: 'Dry Fruit Topping', price: 30 }]
  }
];

// Sample Initial Orders
const INITIAL_ORDERS = [
  {
    id: 'ord-101',
    orderNumber: '#1001',
    channel: 'SWIGGY',
    channelOrderId: 'SWG-902341',
    customer: {
      name: 'Aditya Sharma',
      phone: '+91 98765 43210',
      address: 'Flat 402, Green Glen Layout, Bellandur, Bengaluru'
    },
    items: [
      {
        menuItemId: 'm1',
        name: 'Butter Chicken Masala',
        quantity: 1,
        unitPrice: 340,
        totalPrice: 340,
        addOns: ['Extra Butter'],
        kitchenItemStatus: 'PREPARING'
      },
      {
        menuItemId: 'm6',
        name: 'Garlic Butter Naan',
        quantity: 2,
        unitPrice: 65,
        totalPrice: 130,
        addOns: [],
        kitchenItemStatus: 'PREPARING'
      }
    ],
    financials: {
      itemTotal: 470,
      taxes: 23.5,
      deliveryFee: 35,
      discount: 0,
      grandTotal: 528.5,
      platformCommissionRate: 0.22,
      platformCommissionAmount: 103.4,
      netRestaurantPayout: 366.6
    },
    status: 'IN_KITCHEN',
    prepTimeMinutes: 20,
    acceptedAt: new Date(Date.now() - 8 * 60000),
    rider: {
      name: 'Ramesh Kumar (Swiggy Fleet)',
      phone: '+91 91234 56789',
      status: 'ASSIGNED'
    },
    createdAt: new Date(Date.now() - 10 * 60000),
    timeline: [
      { status: 'PLACED', timestamp: new Date(Date.now() - 10 * 60000), actor: 'Swiggy Webhook' },
      { status: 'ACCEPTED', timestamp: new Date(Date.now() - 8 * 60000), actor: 'POS Terminal' },
      { status: 'IN_KITCHEN', timestamp: new Date(Date.now() - 7 * 60000), actor: 'Kitchen Display' }
    ]
  },
  {
    id: 'ord-102',
    orderNumber: '#1002',
    channel: 'ZOMATO',
    channelOrderId: 'ZMT-488219',
    customer: {
      name: 'Pooja Verma',
      phone: '+91 99887 76655',
      address: 'Tower B, Prestigetech Cloud, Marathahalli'
    },
    items: [
      {
        menuItemId: 'm2',
        name: 'Paneer Butter Masala',
        quantity: 1,
        unitPrice: 280,
        totalPrice: 280,
        addOns: ['Extra Paneer'],
        kitchenItemStatus: 'PENDING'
      },
      {
        menuItemId: 'm8',
        name: 'Kesar Mango Lassi',
        quantity: 1,
        unitPrice: 110,
        totalPrice: 110,
        addOns: [],
        kitchenItemStatus: 'PENDING'
      }
    ],
    financials: {
      itemTotal: 390,
      taxes: 19.5,
      deliveryFee: 40,
      discount: 50,
      grandTotal: 399.5,
      platformCommissionRate: 0.24,
      platformCommissionAmount: 93.6,
      netRestaurantPayout: 296.4
    },
    status: 'PLACED',
    prepTimeMinutes: 20,
    createdAt: new Date(Date.now() - 2 * 60000),
    rider: {
      name: 'Searching nearest rider...',
      phone: '',
      status: 'UNASSIGNED'
    },
    timeline: [
      { status: 'PLACED', timestamp: new Date(Date.now() - 2 * 60000), actor: 'Zomato Webhook' }
    ]
  }
];

// In-Memory store arrays
let menuItems = [...INITIAL_MENU];
let orders = [...INITIAL_ORDERS];
let aggregatorLogs = [];

// Repository interface
const Store = {
  // --- Menu Methods ---
  async getMenuItems() {
    if (!isFallback()) {
      try {
        const items = await MenuItemModel.find();
        if (items && items.length > 0) return items;
      } catch (e) {
        // Fallback to memory
      }
    }
    return menuItems;
  },

  async toggleMenuItemAvailability(id, isAvailable) {
    let updatedItem = null;
    if (!isFallback()) {
      try {
        updatedItem = await MenuItemModel.findByIdAndUpdate(id, { isAvailable }, { new: true });
      } catch (e) {
        // fallback
      }
    }
    const idx = menuItems.findIndex(i => (i.id === id || i._id == id));
    if (idx !== -1) {
      menuItems[idx].isAvailable = isAvailable;
      updatedItem = menuItems[idx];
    }
    return updatedItem;
  },

  async getMenuItemById(id) {
    if (!isFallback()) {
      try {
        const item = await MenuItemModel.findById(id);
        if (item) return item;
      } catch (e) {}
    }
    return menuItems.find(i => i.id === id || i._id == id);
  },

  // --- Order Methods ---
  async getOrders() {
    if (!isFallback()) {
      try {
        const dbOrders = await OrderModel.find().sort({ createdAt: -1 });
        if (dbOrders && dbOrders.length > 0) return dbOrders;
      } catch (e) {}
    }
    return [...orders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },

  async getOrderById(id) {
    if (!isFallback()) {
      try {
        const ord = await OrderModel.findById(id);
        if (ord) return ord;
      } catch (e) {}
    }
    return orders.find(o => o.id === id || o._id == id || o.orderNumber === id);
  },

  async createOrder(orderData) {
    const id = orderData.id || `ord-${Date.now().toString().slice(-6)}`;
    const orderNumber = orderData.orderNumber || `#${1000 + orders.length + 1}`;
    const newOrder = {
      ...orderData,
      id,
      _id: id,
      orderNumber,
      createdAt: orderData.createdAt || new Date(),
      timeline: orderData.timeline || [
        { status: orderData.status || 'PLACED', timestamp: new Date(), actor: orderData.channel || 'DIRECT' }
      ]
    };

    if (!isFallback()) {
      try {
        await OrderModel.create(newOrder);
      } catch (e) {}
    }

    orders.unshift(newOrder);
    return newOrder;
  },

  async updateOrderStatus(id, newStatus, actor = 'STAFF', extraData = {}) {
    let order = orders.find(o => o.id === id || o._id == id || o.orderNumber === id);
    if (!order) return null;

    order.status = newStatus;
    if (newStatus === 'ACCEPTED') {
      order.acceptedAt = new Date();
      if (extraData.prepTimeMinutes) order.prepTimeMinutes = extraData.prepTimeMinutes;
    } else if (newStatus === 'FOOD_READY') {
      order.readyAt = new Date();
    } else if (newStatus === 'OUT_FOR_DELIVERY') {
      if (extraData.rider) order.rider = { ...order.rider, ...extraData.rider };
    }

    if (!order.timeline) order.timeline = [];
    order.timeline.push({
      status: newStatus,
      timestamp: new Date(),
      actor,
      notes: extraData.notes || ''
    });

    if (!isFallback()) {
      try {
        await OrderModel.findOneAndUpdate(
          { $or: [{ _id: id }, { id: id }, { orderNumber: id }] },
          { $set: order },
          { new: true }
        );
      } catch (e) {}
    }

    return order;
  },

  // --- Aggregator Audit Logs ---
  async logAggregatorEvent(logData) {
    const logEntry = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date(),
      ...logData
    };

    aggregatorLogs.unshift(logEntry);
    if (aggregatorLogs.length > 100) aggregatorLogs.pop(); // keep last 100

    if (!isFallback()) {
      try {
        await AggregatorLogModel.create(logEntry);
      } catch (e) {}
    }

    return logEntry;
  },

  async getAggregatorLogs() {
    if (!isFallback()) {
      try {
        const logs = await AggregatorLogModel.find().sort({ createdAt: -1 }).limit(50);
        if (logs && logs.length > 0) return logs;
      } catch (e) {}
    }
    return aggregatorLogs;
  }
};

module.exports = Store;
