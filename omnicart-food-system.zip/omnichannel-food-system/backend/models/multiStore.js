/**
 * OmniCart Universal Pan-India Food Network Engine
 * Covers the entire geography of India from Top (Kashmir/Punjab/Himachal) 
 * to Bottom (Kerala/Kanyakumari/Tamil Nadu), East (Assam/Bengal), West (Gujarat/Rajasthan) 
 * and Central Heartlands, with dynamic resolver for ANY city, town, or village.
 */

const INDIA_ZONES = [
  { id: 'ALL', name: '🇮🇳 All India', tag: 'Top to Bottom (National)' },
  { id: 'NORTH', name: '🏔️ North India', tag: 'Kashmir, Punjab, Himachal, UP, Delhi' },
  { id: 'SOUTH', name: '🌴 South India', tag: 'Kerala, Tamil Nadu, Karnataka, AP, Kanyakumari' },
  { id: 'WEST', name: '🏜️ West India', tag: 'Rajasthan, Gujarat, Maharashtra, Goa' },
  { id: 'EAST', name: '🍵 East & North-East', tag: 'Bengal, Assam, Odisha, Sikkim, Bihar' },
  { id: 'CENTRAL', name: '🌾 Central & Rural', tag: 'MP, Village Dhabas & Kisan Marts' },
];

const PRESEEDED_OUTLETS = [
  // =========================================================================
  // TOP OF INDIA (NORTH: Kashmir, Punjab, Himachal, Uttarakhand, Delhi, UP)
  // =========================================================================
  {
    id: 'res-kashmir-wazwan',
    zone: 'NORTH',
    city: 'srinagar',
    cityName: 'Srinagar (Jammu & Kashmir)',
    state: 'Jammu & Kashmir',
    name: 'Ahdoos Royal Kashmiri Wazwan (Est. 1918)',
    outletType: 'RESTAURANT',
    typeLabel: 'Heritage Kashmiri Wazwan',
    tagline: 'Top of India • Authentic Royal Kashmiri Wazwan & Kahwa',
    cuisine: 'Kashmiri Wazwan • Rista • Rogan Josh • Kahwa',
    rating: 4.9,
    reviewsCount: '6.4k',
    distance: '0.4 km',
    prepTimeMinutes: 20,
    hubLocation: 'Residency Road & Dal Lake Hub, Srinagar, Kashmir',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=500&q=80',
    color: '#991B1B',
    categories: ['Royal Wazwan Curries', 'Tandoori Grills', 'Traditional Kahwa & Breads'],
    menu: [
      {
        id: 'kas-1',
        restaurantId: 'res-kashmir-wazwan',
        restaurantName: 'Ahdoos Royal Kashmiri Wazwan',
        name: 'Wazwan Mutton Rogan Josh in Kashmiri Saffron',
        price: 460,
        isVeg: false,
        category: 'Royal Wazwan Curries',
        description: 'Tender baby lamb cooked in aromatic Kashmiri dried cockscomb flower, mawal extract, and fennel.',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'kas-2',
        restaurantId: 'res-kashmir-wazwan',
        restaurantName: 'Ahdoos Royal Kashmiri Wazwan',
        name: 'Gushtaba (Royal Pounded Lamb Meatball in Curd)',
        price: 480,
        isVeg: false,
        category: 'Royal Wazwan Curries',
        description: 'Hand-pounded minced mutton balls poached in a rich fragrant yogurt and saffron gravy.',
        image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'kas-3',
        restaurantId: 'res-kashmir-wazwan',
        restaurantName: 'Ahdoos Royal Kashmiri Wazwan',
        name: 'Shahi Saffron Almond Kashmiri Kahwa Tea',
        price: 90,
        isVeg: true,
        category: 'Traditional Kahwa & Breads',
        description: 'Green tea brewed in brass samovar with whole Kashmiri saffron strands, crushed almonds, and cinnamon.',
        image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=400&q=80'
      }
    ]
  },
  {
    id: 'res-amritsar-dhaba',
    zone: 'NORTH',
    city: 'amritsar',
    cityName: 'Amritsar (Punjab)',
    state: 'Punjab',
    name: 'Kesar Da Dhaba (Est. 1916)',
    outletType: 'RESTAURANT',
    typeLabel: 'Legendary Punjabi Dhaba',
    tagline: 'North Heartlands • Slow-Cooked Pure Ghee Dal Makhani & Kulchas',
    cuisine: 'Punjabi Dhaba • Amritsari Kulcha • Pure Desi Ghee',
    rating: 4.9,
    reviewsCount: '12.8k',
    distance: '0.3 km',
    prepTimeMinutes: 15,
    hubLocation: 'Chowk Passian, Near Golden Temple, Amritsar',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=500&q=80',
    color: '#D97706',
    categories: ['Dhaba Specialties', 'Amritsari Kulchas', 'Desi Ghee Sweets'],
    menu: [
      {
        id: 'amr-1',
        restaurantId: 'res-amritsar-dhaba',
        restaurantName: 'Kesar Da Dhaba',
        name: 'Famous 12-Hour Slow Cooked Dal Makhani',
        price: 240,
        isVeg: true,
        category: 'Dhaba Specialties',
        description: 'Black urad lentils simmered overnight on slow coals, finished with copious ladles of pure desi ghee.',
        image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'amr-2',
        restaurantId: 'res-amritsar-dhaba',
        restaurantName: 'Kesar Da Dhaba',
        name: 'Crispy Amritsari Aloo Pyaaz Chur Chur Kulcha (2 Pcs)',
        price: 180,
        isVeg: true,
        category: 'Amritsari Kulchas',
        description: 'Flaky multi-layered spiced potato-onion tandoori flatbread crushed with butter, served with pindi chole.',
        image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'amr-3',
        restaurantId: 'res-amritsar-dhaba',
        restaurantName: 'Kesar Da Dhaba',
        name: 'Pure Desi Ghee Phirni in Earthen Sakora',
        price: 80,
        isVeg: true,
        category: 'Desi Ghee Sweets',
        description: 'Chilled ground rice and condensed milk pudding flavored with green cardamom and slivered pistachios.',
        image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=400&q=80'
      }
    ]
  },
  {
    id: 'res-shimla-bakery',
    zone: 'NORTH',
    city: 'shimla',
    cityName: 'Shimla & Manali (Himachal Pradesh)',
    state: 'Himachal Pradesh',
    name: 'The Mall Road Alpine Bakery & Cafe',
    outletType: 'CAFE',
    typeLabel: 'Hill Station Alpine Cafe',
    tagline: 'Himachal Hills • Fresh Apple Pies, Sourdough Bakes & Mountain Tea',
    cuisine: 'Cafe • Mountain Bakes • Apple Desserts • Hot Cocoa',
    rating: 4.8,
    reviewsCount: '3.9k',
    distance: '0.2 km',
    prepTimeMinutes: 10,
    hubLocation: 'The Mall & Ridge, Shimla, Himachal Pradesh',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=500&q=80',
    color: '#047857',
    categories: ['Himachal Apple Treats', 'Warm Soups & Sandwiches', 'Hot Brews'],
    menu: [
      {
        id: 'shm-1',
        restaurantId: 'res-shimla-bakery',
        restaurantName: 'The Mall Road Alpine Bakery & Cafe',
        name: 'Warm Kinnaur Spiced Apple Cinnamon Pie',
        price: 180,
        isVeg: true,
        category: 'Himachal Apple Treats',
        description: 'Flaky double-crust pie stuffed with caramelized mountain apples, nutmeg, and vanilla sauce.',
        image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'shm-2',
        restaurantId: 'res-shimla-bakery',
        restaurantName: 'The Mall Road Alpine Bakery & Cafe',
        name: 'Mountain Roasted Chicken & Cheese Croissant',
        price: 240,
        isVeg: false,
        category: 'Warm Soups & Sandwiches',
        description: 'Buttery flaky pastry stuffed with pulled herb chicken, melted gouda, and dijon mustard.',
        image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=400&q=80'
      }
    ]
  },

  // =========================================================================
  // BOTTOM OF INDIA (SOUTH: Kanyakumari, Kerala, Tamil Nadu, Karnataka, AP)
  // =========================================================================
  {
    id: 'res-kanya-coastal',
    zone: 'SOUTH',
    city: 'kanyakumari',
    cityName: 'Kanyakumari (Tamil Nadu)',
    state: 'Tamil Nadu',
    name: 'Cape Comorin Sea View Tiffin & Seafood',
    outletType: 'RESTAURANT',
    typeLabel: 'Triveni Sangam Coastal Kitchen',
    tagline: 'Bottom of India • 3-Oceans Confluence Fresh Catch & Ghee Tiffin',
    cuisine: 'Coastal Tamil • Coconut Seafood • Parotta • Filter Coffee',
    rating: 4.8,
    reviewsCount: '4.7k',
    distance: '0.3 km',
    prepTimeMinutes: 15,
    hubLocation: 'Beach Road & Sunset Point, Kanyakumari (Southern Tip of India)',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=500&q=80',
    color: '#0284C7',
    categories: ['Ocean Catch Roasts', 'Southern Parotta Combos', 'Traditional Kaapi'],
    menu: [
      {
        id: 'kan-1',
        restaurantId: 'res-kanya-coastal',
        restaurantName: 'Cape Comorin Sea View Tiffin & Seafood',
        name: 'Kanyakumari Banana Leaf Masala Seer Fish Fry',
        price: 360,
        isVeg: false,
        category: 'Ocean Catch Roasts',
        description: 'Fresh Vanjaram kingfish slice marinated in crushed shallots, curry leaves, and griddled in pure coconut oil.',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'kan-2',
        restaurantId: 'res-kanya-coastal',
        restaurantName: 'Cape Comorin Sea View Tiffin & Seafood',
        name: 'Southern Border Flaky Parotta with Salna (3 Pcs)',
        price: 120,
        isVeg: true,
        category: 'Southern Parotta Combos',
        description: 'Airy layered flatbread beaten hot and served with fragrant spiced tomato-coconut salna.',
        image: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'kan-3',
        restaurantId: 'res-kanya-coastal',
        restaurantName: 'Cape Comorin Sea View Tiffin & Seafood',
        name: 'Nanjil Coconut Milk Payasam Bowl',
        price: 90,
        isVeg: true,
        category: 'Traditional Kaapi',
        description: 'Warm jaggery and fresh extracted coconut milk dessert with roasted cashews and cardamom.',
        image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=400&q=80'
      }
    ]
  },
  {
    id: 'res-kochi-seafood',
    zone: 'SOUTH',
    city: 'kochi',
    cityName: 'Kochi & Alleppey (Kerala)',
    state: 'Kerala',
    name: 'Fort Kochi Heritage Spice & Backwater Cafe',
    outletType: 'RESTAURANT',
    typeLabel: 'Malabar Coastal Kitchen',
    tagline: 'Gods Own Country • Claypot Fish Curry & Malabar Biryani',
    cuisine: 'Kerala Coastal • Appam • Malabar Biryani • Coconut Stew',
    rating: 4.9,
    reviewsCount: '7.1k',
    distance: '0.4 km',
    prepTimeMinutes: 18,
    hubLocation: 'Princess Street, Fort Kochi & Backwaters, Kerala',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=500&q=80',
    color: '#059669',
    categories: ['Backwater Curries', 'Malabar Specialties', 'Kerala Snacks'],
    menu: [
      {
        id: 'koc-1',
        restaurantId: 'res-kochi-seafood',
        restaurantName: 'Fort Kochi Heritage Spice & Backwater Cafe',
        name: 'Traditional Meen Pollichathu (Karimeen Pearl Spot)',
        price: 420,
        isVeg: false,
        category: 'Backwater Curries',
        description: 'Fresh backwater fish wrapped in scorched banana leaf with roasted shallot masala and cocum.',
        image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'koc-2',
        restaurantId: 'res-kochi-seafood',
        restaurantName: 'Fort Kochi Heritage Spice & Backwater Cafe',
        name: 'Thalassery Chicken Dum Biryani with Kaima Rice',
        price: 340,
        isVeg: false,
        category: 'Malabar Specialties',
        description: 'Fragrant short-grain jeerakasala rice cooked with tender chicken, sultanas, and fried cashew nuts.',
        image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'koc-3',
        restaurantId: 'res-kochi-seafood',
        restaurantName: 'Fort Kochi Heritage Spice & Backwater Cafe',
        name: 'Fluffy Lace Appam with Vegetable Stew (2 Appams)',
        price: 160,
        isVeg: true,
        category: 'Malabar Specialties',
        description: 'Fermented rice bowl pancakes with crispy edges and soft pillowy centers, with rich coconut milk stew.',
        image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=400&q=80'
      }
    ]
  },

  // =========================================================================
  // WEST OF INDIA (Gujarat, Rajasthan, Maharashtra, Goa)
  // =========================================================================
  {
    id: 'res-raj-thali',
    zone: 'WEST',
    city: 'jaipur',
    cityName: 'Jaipur & Udaipur (Rajasthan)',
    state: 'Rajasthan',
    name: 'Chokhi Dhani Royal Rajputana Thali',
    outletType: 'RESTAURANT',
    typeLabel: 'Royal Desert Heritage',
    tagline: 'West Land of Forts • Authentic Dal Baati Churma & Laal Maas',
    cuisine: 'Rajasthani • Dal Baati Churma • Royal Game Curries',
    rating: 4.8,
    reviewsCount: '10.5k',
    distance: '0.5 km',
    prepTimeMinutes: 20,
    hubLocation: 'Tonk Road & Hawa Mahal Hub, Jaipur, Rajasthan',
    image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=500&q=80',
    color: '#B45309',
    categories: ['Royal Thali Items', 'Rajputana Curries', 'Churma Sweets'],
    menu: [
      {
        id: 'raj-1',
        restaurantId: 'res-raj-thali',
        restaurantName: 'Chokhi Dhani Royal Rajputana Thali',
        name: 'Royal Dal Baati Churma Feast with Pure Desi Ghee',
        price: 380,
        isVeg: true,
        category: 'Royal Thali Items',
        description: 'Hard wheat flour balls dipped in pure desi ghee, served with panchmel dal, garlic chutney and sweet churma.',
        image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'raj-2',
        restaurantId: 'res-raj-thali',
        restaurantName: 'Chokhi Dhani Royal Rajputana Thali',
        name: 'Fiery Mathania Laal Maas (Mutton Gravy)',
        price: 440,
        isVeg: false,
        category: 'Rajputana Curries',
        description: 'Tender baby mutton simmered in fiery red Mathania chili paste, smoked charcoal cloves, and mustard oil.',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&q=80'
      }
    ]
  },
  {
    id: 'res-guj-farsan',
    zone: 'WEST',
    city: 'ahmedabad',
    cityName: 'Ahmedabad & Surat (Gujarat)',
    state: 'Gujarat',
    name: 'Das Khaman & Gujarati Farsan House',
    outletType: 'STORE',
    typeLabel: 'Iconic Farsan & Snack House',
    tagline: 'West India • Spongy Steamed Nylon Khaman, Jalebi & Fafda',
    cuisine: 'Gujarati Snacks • Farsan • Sweets',
    rating: 4.8,
    reviewsCount: '5.6k',
    distance: '0.2 km',
    prepTimeMinutes: 5,
    hubLocation: 'Manek Chowk & Ashram Road, Ahmedabad, Gujarat',
    image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=500&q=80',
    color: '#EAB308',
    categories: ['Steamed Farsan', 'Crispy Fafda & Jalebi', 'Cold Refreshers'],
    menu: [
      {
        id: 'guj-1',
        restaurantId: 'res-guj-farsan',
        restaurantName: 'Das Khaman & Gujarati Farsan House',
        name: 'Steamed Cotton Soft Nylon Khaman Dhokla (250g)',
        price: 110,
        isVeg: true,
        category: 'Steamed Farsan',
        description: 'Light, melt-in-mouth gram flour steamed cakes tempered with mustard seeds, green chilies, and coriander.',
        image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'guj-2',
        restaurantId: 'res-guj-farsan',
        restaurantName: 'Das Khaman & Gujarati Farsan House',
        name: 'Crisp Fafda with Raw Papaya Sambharo & Hot Jalebi Combo',
        price: 160,
        isVeg: true,
        category: 'Crispy Fafda & Jalebi',
        description: 'Traditional crunchy besan strips served with spiced grated raw papaya salad and hot dripping jalebis.',
        image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=400&q=80'
      }
    ]
  },

  // =========================================================================
  // EAST & NORTHEAST (Assam, Bengal, Odisha, Sikkim, Bihar)
  // =========================================================================
  {
    id: 'res-assam-teahouse',
    zone: 'EAST',
    city: 'guwahati',
    cityName: 'Guwahati & Shillong (Northeast India)',
    state: 'Assam',
    name: 'Brahmaputra Valley Tea Lounge & Grills',
    outletType: 'CAFE',
    typeLabel: 'Northeast Tea & Grill Lounge',
    tagline: 'Far East India • Single Estate Orthodox Teas & Smoked Pork/Chicken',
    cuisine: 'Northeastern • Specialty Tea • Steamed Momos • Smoked Grills',
    rating: 4.9,
    reviewsCount: '4.2k',
    distance: '0.4 km',
    prepTimeMinutes: 12,
    hubLocation: 'GS Road & Uzan Bazar, Guwahati, Assam',
    image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=500&q=80',
    color: '#15803D',
    categories: ['Single Estate Teas', 'Darjeeling Steamed Momos', 'Bamboo Shoot Delights'],
    menu: [
      {
        id: 'asm-1',
        restaurantId: 'res-assam-teahouse',
        restaurantName: 'Brahmaputra Valley Tea Lounge & Grills',
        name: 'First Flush Golden Tip Assam Orthodox Tea Pot',
        price: 140,
        isVeg: true,
        category: 'Single Estate Teas',
        description: 'Rare golden tippy black tea leaves hand-plucked from Upper Brahmaputra valley gardens.',
        image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'asm-2',
        restaurantId: 'res-assam-teahouse',
        restaurantName: 'Brahmaputra Valley Tea Lounge & Grills',
        name: 'Juicy Steamed Himalayan Chicken Momos (8 Pcs)',
        price: 190,
        isVeg: false,
        category: 'Darjeeling Steamed Momos',
        description: 'Delicate hand-pinched dumplings packed with minced chicken and ginger, served with fiery Dalle chili chutney.',
        image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=400&q=80'
      }
    ]
  },

  // =========================================================================
  // CENTRAL & RURAL VILLAGES (Village Dhabas & Kisan Fresh Marts)
  // =========================================================================
  {
    id: 'res-gramin-dhaba',
    zone: 'CENTRAL',
    city: 'village-hub',
    cityName: 'Rural & Village Highway Hub (Grand Trunk Road)',
    state: 'Heartland India',
    name: 'Kisan Gramin Dhaba & Organic Farm Kitchen',
    outletType: 'RESTAURANT',
    typeLabel: 'Village Chulha Dhaba',
    tagline: 'Heart of India • Mud Chulha Flatbreads, Sarson Ka Saag & Fresh Farm Ghee',
    cuisine: 'Village Dhaba • Claypot Cooking • Farm Organic',
    rating: 4.9,
    reviewsCount: '8.3k',
    distance: '0.5 km',
    prepTimeMinutes: 15,
    hubLocation: 'National Highway Highway Cluster & Gramin Haat',
    image: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=500&q=80',
    color: '#854D0E',
    categories: ['Chulha Flatbreads & Saag', 'Gramin Claypot Gravies', 'Farm Dairy Sweets'],
    menu: [
      {
        id: 'vil-1',
        restaurantId: 'res-gramin-dhaba',
        restaurantName: 'Kisan Gramin Dhaba & Organic Farm Kitchen',
        name: 'Sarson Ka Saag with Makki Ki Roti & White Butter',
        price: 210,
        isVeg: true,
        category: 'Chulha Flatbreads & Saag',
        description: 'Slow-churned mustard greens cooked with bathua and spinach, served with corn flatbreads, jaggery and fresh white butter.',
        image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'vil-2',
        restaurantId: 'res-gramin-dhaba',
        restaurantName: 'Kisan Gramin Dhaba & Organic Farm Kitchen',
        name: 'Handi Champaran Ahuna Mutton in Earthen Pot',
        price: 430,
        isVeg: false,
        category: 'Gramin Claypot Gravies',
        description: 'Meat marinated with whole garlic pods, sealed with dough in earthen pots and cooked on woodfire embers.',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&q=80'
      },
      {
        id: 'vil-3',
        restaurantId: 'res-gramin-dhaba',
        restaurantName: 'Kisan Gramin Dhaba & Organic Farm Kitchen',
        name: 'Pure Buffalo Milk Rabri in Terracotta Matka',
        price: 90,
        isVeg: true,
        category: 'Farm Dairy Sweets',
        description: 'Thick creamy layers of slow-reduced organic farm buffalo milk sweetened with natural sugarcane jaggery.',
        image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=400&q=80'
      }
    ]
  }
];

let multiOrders = [];

const MultiStore = {
  getZones() {
    return INDIA_ZONES;
  },

  getCities() {
    // Unique list of cities pre-seeded
    return PRESEEDED_OUTLETS.map(r => ({
      id: r.city,
      name: r.cityName,
      zone: r.zone,
      hubName: r.hubLocation,
      state: r.state
    })).filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);
  },

  getHubRestaurants(filterQuery = null, zoneFilter = 'ALL') {
    let results = [...PRESEEDED_OUTLETS];

    // Filter by Zone if provided
    if (zoneFilter && zoneFilter !== 'ALL') {
      results = results.filter(r => r.zone === zoneFilter);
    }

    // Filter by city / search query
    if (filterQuery && filterQuery !== 'ALL' && filterQuery.trim() !== '') {
      const q = filterQuery.toLowerCase().trim();
      const cityMatches = results.filter(r => 
        r.city.toLowerCase() === q || 
        r.cityName.toLowerCase().includes(q) ||
        r.state.toLowerCase().includes(q)
      );

      if (cityMatches.length > 0) {
        return cityMatches;
      }

      // If user searched for ANY town or village not pre-seeded (e.g. "Rampur", "Dharmapuri", "Manali Village", etc.)
      // Dynamically synthesize a complete local Food Cluster for that exact town/village!
      const capitalizedLocation = q.charAt(0).toUpperCase() + q.slice(1);
      return this.synthesizeDynamicTownCluster(capitalizedLocation);
    }

    return results;
  },

  /**
   * Dynamic Town / Village Cluster Synthesizer
   * Guarantees 100% coverage of ANY town, village, or district entered by user!
   */
  synthesizeDynamicTownCluster(locationName) {
    return [
      {
        id: `dyn-dhaba-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
        zone: 'DYNAMIC',
        city: locationName.toLowerCase(),
        cityName: `${locationName} Local Cluster`,
        state: 'Local Region',
        name: `${locationName} Highway Dhaba & Family Restaurant`,
        outletType: 'RESTAURANT',
        typeLabel: 'Local Town Restaurant',
        tagline: `Fresh Desi Cooking & Tandoori Feasts in ${locationName}`,
        cuisine: 'North & Regional Indian • Tandoor • Thali',
        rating: 4.8,
        reviewsCount: '1.4k',
        distance: '0.3 km',
        prepTimeMinutes: 15,
        hubLocation: `${locationName} Main Market & Chowk Hub`,
        image: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=500&q=80',
        color: '#D97706',
        categories: ['Local Tandoor Curries', 'Chulha Roti Combos', 'Regional Specials'],
        menu: [
          {
            id: `dyn-1-${locationName}`,
            restaurantId: `dyn-dhaba-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
            restaurantName: `${locationName} Highway Dhaba`,
            name: `${locationName} Special Shahi Paneer Thali`,
            price: 240,
            isVeg: true,
            category: 'Local Tandoor Curries',
            description: `Rich cottage cheese curry with butter naans, jeera rice, and dal fry freshly prepared in ${locationName}.`,
            image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=400&q=80'
          },
          {
            id: `dyn-2-${locationName}`,
            restaurantId: `dyn-dhaba-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
            restaurantName: `${locationName} Highway Dhaba`,
            name: `${locationName} Desi Murgh Tandoori Roast`,
            price: 330,
            isVeg: false,
            category: 'Local Tandoor Curries',
            description: `Clay-oven spiced roasted chicken with green chutney and laccha onions.`,
            image: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=400&q=80'
          }
        ]
      },
      {
        id: `dyn-sweets-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
        zone: 'DYNAMIC',
        city: locationName.toLowerCase(),
        cityName: `${locationName} Local Cluster`,
        state: 'Local Region',
        name: `${locationName} Halwai & Chai Chowk`,
        outletType: 'DESSERT',
        typeLabel: 'Town Halwai & Sweets',
        tagline: `Fresh Hot Jalebis, Samosas, Rabri & Kulhad Chai in ${locationName}`,
        cuisine: 'Halwai Sweets • Chai & Snacks • Lassi',
        rating: 4.9,
        reviewsCount: '2.1k',
        distance: '0.2 km',
        prepTimeMinutes: 5,
        hubLocation: `${locationName} Station Road & Bazaar`,
        image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=500&q=80',
        color: '#EA580C',
        categories: ['Hot Fried Snacks', 'Fresh Halwai Sweets', 'Kulhad Chai'],
        menu: [
          {
            id: `dyn-3-${locationName}`,
            restaurantId: `dyn-sweets-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
            restaurantName: `${locationName} Halwai & Chai Chowk`,
            name: `Hot Crispy Samosas & Mint Chutney (2 Pcs)`,
            price: 40,
            isVeg: true,
            category: 'Hot Fried Snacks',
            description: `Golden crunchy triangular potato puffs seasoned with crushed coriander seeds and garam masala.`,
            image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=400&q=80'
          },
          {
            id: `dyn-4-${locationName}`,
            restaurantId: `dyn-sweets-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
            restaurantName: `${locationName} Halwai & Chai Chowk`,
            name: `Pure Desi Ghee Jalebi with Rabri (250g)`,
            price: 120,
            isVeg: true,
            category: 'Fresh Halwai Sweets',
            description: `Crispy spirals of fermented batter fried in desi ghee, steeped in hot saffron sugar syrup.`,
            image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=400&q=80'
          }
        ]
      },
      {
        id: `dyn-mart-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
        zone: 'DYNAMIC',
        city: locationName.toLowerCase(),
        cityName: `${locationName} Local Cluster`,
        state: 'Local Region',
        name: `${locationName} Village Kisan Mart & Fresh Dairy`,
        outletType: 'STORE',
        typeLabel: 'Local Farm Dairy & Grocery',
        tagline: `Fresh Village Buffalo Milk, Paneer & Organic Grains from ${locationName}`,
        cuisine: 'Dairy • Cold Pressed Oils • Farm Produce',
        rating: 4.8,
        reviewsCount: '890',
        distance: '0.6 km',
        prepTimeMinutes: 5,
        hubLocation: `${locationName} Mandi Yard & Agro Hub`,
        image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=500&q=80',
        color: '#15803D',
        categories: ['Farm Fresh Dairy', 'Village Staple Provisions'],
        menu: [
          {
            id: `dyn-5-${locationName}`,
            restaurantId: `dyn-mart-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
            restaurantName: `${locationName} Village Kisan Mart`,
            name: 'Fresh Malai Paneer Block (400g)',
            price: 140,
            isVeg: true,
            category: 'Farm Fresh Dairy',
            description: 'Unprocessed soft cottage cheese curd set fresh this morning from local village cattle.',
            image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=400&q=80'
          },
          {
            id: `dyn-6-${locationName}`,
            restaurantId: `dyn-mart-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
            restaurantName: `${locationName} Village Kisan Mart`,
            name: 'Cold Pressed Kachi Ghani Mustard Oil (1L Bottle)',
            price: 185,
            isVeg: true,
            category: 'Village Staple Provisions',
            description: 'Wood-churned pure pungent mustard oil extracted directly from surrounding local fields.',
            image: 'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&w=400&q=80'
          }
        ]
      },
      {
        id: `dyn-cafe-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
        zone: 'DYNAMIC',
        city: locationName.toLowerCase(),
        cityName: `${locationName} Local Cluster`,
        state: 'Local Region',
        name: `${locationName} Kulhad Chai & Snacks Adda`,
        outletType: 'CAFE',
        typeLabel: 'Regional Tea Stall & Snacks',
        tagline: `Steaming Clay-Cup Ginger Chai & Toasted Maska Pav in ${locationName}`,
        cuisine: 'Kulhad Chai • Bun Maska • Pakoras',
        rating: 4.9,
        reviewsCount: '3.2k',
        distance: '0.1 km',
        prepTimeMinutes: 5,
        hubLocation: `${locationName} Chowk Peepal Tree Adda`,
        image: 'https://images.unsplash.com/photo-1571934811356-5cc061b6821f?auto=format&fit=crop&w=500&q=80',
        color: '#B45309',
        categories: ['Special Clay Cup Chai', 'Quick Tea-Time Bites'],
        menu: [
          {
            id: `dyn-7-${locationName}`,
            restaurantId: `dyn-cafe-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
            restaurantName: `${locationName} Kulhad Chai Adda`,
            name: 'Special Elaichi Adrak Kulhad Chai (2 Cups)',
            price: 50,
            isVeg: true,
            category: 'Special Clay Cup Chai',
            description: 'Boiled creamy milk tea infused with freshly smashed ginger root and green cardamom.',
            image: 'https://images.unsplash.com/photo-1571934811356-5cc061b6821f?auto=format&fit=crop&w=400&q=80'
          },
          {
            id: `dyn-8-${locationName}`,
            restaurantId: `dyn-cafe-${locationName.toLowerCase().replace(/\s+/g, '-')}`,
            restaurantName: `${locationName} Kulhad Chai Adda`,
            name: 'Butter Toasted Bun Maska (2 Pcs)',
            price: 60,
            isVeg: true,
            category: 'Quick Tea-Time Bites',
            description: 'Fluffy local bakery buns sliced and filled with luscious salted farm butter.',
            image: 'https://images.unsplash.com/photo-1509722747041-616f39b57569?auto=format&fit=crop&w=400&q=80'
          }
        ]
      }
    ];
  },

  getAllMenuItems() {
    return PRESEEDED_OUTLETS.flatMap(r => r.menu);
  },

  getRestaurantById(id) {
    const found = PRESEEDED_OUTLETS.find(r => r.id === id);
    if (found) return found;
    if (id && id.startsWith('dyn-')) {
      return {
        id,
        name: 'Local Regional Partner',
        hubLocation: 'Local Village & Town Hub'
      };
    }
    return null;
  },

  getMultiOrders() {
    return multiOrders;
  },

  getMultiOrderById(id) {
    return multiOrders.find(o => o.id === id || o.orderNumber === id);
  },

  createMultiOrder(orderData) {
    const id = `mo-${Date.now()}`;
    const orderNumber = `#MC-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder = {
      ...orderData,
      id,
      orderNumber,
      createdAt: new Date(),
      status: 'PLACED',
      routeProgress: 0,
    };

    multiOrders.unshift(newOrder);
    return newOrder;
  },

  advanceRouteStop(orderId) {
    const order = multiOrders.find(o => o.id === orderId || o.orderNumber === orderId);
    if (!order) return null;

    if (order.routeProgress < order.multiStopRoute.stops.length - 1) {
      order.routeProgress += 1;
      const currentStop = order.multiStopRoute.stops[order.routeProgress];
      
      if (currentStop.type === 'PICKUP') {
        order.status = 'RIDER_PICKING_UP';
        const sub = order.subOrders.find(s => s.restaurantId === currentStop.restaurantId);
        if (sub) sub.status = 'COLLECTED_BY_RIDER';
      } else if (currentStop.type === 'DROPOFF') {
        order.status = 'DELIVERED';
      }
    } else {
      order.status = 'DELIVERED';
    }

    return order;
  }
};

module.exports = MultiStore;
