const mongoose = require('mongoose');

// --- Menu Item Schema ---
const MenuItemSchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: String, required: true }, // 'Starters', 'Main Course', 'Breads & Rice', 'Desserts', 'Beverages'
  description: { type: String },
  price: { type: Number, required: true },
  isVeg: { type: Boolean, default: true },
  isAvailable: { type: Boolean, default: true },
  swiggyItemId: { type: String },
  zomatoItemId: { type: String },
  preparationTimeMinutes: { type: Number, default: 15 },
  imageUrl: { type: String },
  addOns: [{
    name: String,
    price: Number,
  }],
}, { timestamps: true });

// --- Order Item Sub-schema ---
const OrderItemSchema = new mongoose.Schema({
  menuItemId: { type: String, required: true },
  name: { type: String, required: true },
  quantity: { type: Number, required: true },
  unitPrice: { type: Number, required: true },
  totalPrice: { type: Number, required: true },
  addOns: [String],
  notes: String,
  kitchenItemStatus: {
    type: String,
    enum: ['PENDING', 'PREPARING', 'READY'],
    default: 'PENDING'
  }
});

// --- Unified Order Schema ---
const OrderSchema = new mongoose.Schema({
  orderNumber: { type: String, required: true, unique: true },
  channel: { 
    type: String, 
    enum: ['DIRECT', 'SWIGGY', 'ZOMATO'], 
    required: true 
  },
  channelOrderId: { type: String }, // e.g., SWG-89412 or ZMT-33109
  customer: {
    name: { type: String, required: true },
    phone: { type: String, required: true },
    address: { type: String, default: 'Dine-in / Direct Pickup' },
  },
  items: [OrderItemSchema],
  financials: {
    itemTotal: { type: Number, required: true },
    taxes: { type: Number, default: 0 },
    deliveryFee: { type: Number, default: 0 },
    discount: { type: Number, default: 0 },
    grandTotal: { type: Number, required: true },
    platformCommissionRate: { type: Number, default: 0 }, // e.g. 0.22 for Swiggy (22%)
    platformCommissionAmount: { type: Number, default: 0 },
    netRestaurantPayout: { type: Number, required: true },
  },
  status: {
    type: String,
    enum: [
      'PLACED',             // Ingested, ringing on POS
      'ACCEPTED',           // Cashier accepted & prep time set
      'IN_KITCHEN',         // KDS active prep
      'FOOD_READY',         // Packed, waiting for pickup/rider
      'OUT_FOR_DELIVERY',   // Rider picked up
      'DELIVERED',          // Finished
      'CANCELLED'           // Cancelled with reason
    ],
    default: 'PLACED'
  },
  prepTimeMinutes: { type: Number, default: 20 },
  acceptedAt: { type: Date },
  readyAt: { type: Date },
  rider: {
    name: { type: String },
    phone: { type: String },
    status: { type: String, enum: ['UNASSIGNED', 'ASSIGNED', 'ARRIVED_AT_STORE', 'TRANSIT', 'DELIVERED'], default: 'UNASSIGNED' },
  },
  timeline: [{
    status: String,
    timestamp: { type: Date, default: Date.now },
    actor: String,
    notes: String,
  }],
}, { timestamps: true });

// --- Aggregator Webhook Audit Log Schema ---
const AggregatorLogSchema = new mongoose.Schema({
  source: { type: String, enum: ['SWIGGY', 'ZOMATO'], required: true },
  eventType: { type: String, required: true }, // 'ORDER_PLACED', 'RIDER_ASSIGNED', 'CANCEL_ORDER', 'STATUS_CALLBACK'
  channelOrderId: { type: String },
  payload: { type: mongoose.Schema.Types.Mixed },
  normalizedUnifiedOrder: { type: mongoose.Schema.Types.Mixed },
  status: { type: String, default: 'PROCESSED' },
  processingLatencyMs: { type: Number },
  createdAt: { type: Date, default: Date.now },
});

module.exports = {
  MenuItemModel: mongoose.model('MenuItem', MenuItemSchema),
  OrderModel: mongoose.model('Order', OrderSchema),
  AggregatorLogModel: mongoose.model('AggregatorLog', AggregatorLogSchema),
};
