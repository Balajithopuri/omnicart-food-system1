# 🇮🇳 OmniCart: Pan-India Food Ordering & Restaurant Management System
> **Solving the Multi-Restaurant Problem of Swiggy & Zomato Across Every City, Town, and Village in India.**

[![React](https://img.shields.io/badge/Frontend-React%2019%20%2B%20Vite-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![Node.js](https://img.shields.io/badge/Backend-Node.js%20%2B%20Express-339933?logo=node.js&logoColor=white)](https://nodejs.org/)
[![MongoDB](https://img.shields.io/badge/Database-MongoDB%20Mongoose-47A248?logo=mongodb&logoColor=white)](https://www.mongodb.com/)
[![Socket.io](https://img.shields.io/badge/Real--Time-WebSockets%20Socket.io-010101?logo=socket.io&logoColor=white)](https://socket.io/)
[![Tailwind CSS](https://img.shields.io/badge/Styling-Tailwind%20CSS-06B6D4?logo=tailwindcss&logoColor=white)](https://tailwindcss.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 🌟 Live Demo
* **Live Public URL**: [https://replied-calgary-terrorism-enhanced.trycloudflare.com](https://replied-calgary-terrorism-enhanced.trycloudflare.com)
* **Localhost URL**: `http://localhost:5000` (Unified Production) or `http://localhost:5173` (Vite Dev)

---

## 💡 The Core Innovation

On **Swiggy and Zomato**, carts are restricted to **exactly 1 restaurant**:
* Want **Biryani** from *Outlet A* and **Dessert** from *Outlet B*?
  * Customers must place **2 separate orders**.
  * Pay **2 separate delivery fees** + 2 platform fees.
  * Two riders on the road (doubling carbon footprint and traffic).
  * Food arrives at different times (desserts melt before biryani arrives).

**OmniCart** introduces **Food Hub Clustering & Multi-Stop Route Dispatching**:
* Combine dishes from **multiple nearby restaurants, cafes, and bakeries** into **ONE unified cart**.
* **1 Single Checkout** with **1 Consolidated Delivery Fee** (saves ₹30 to ₹75+ per order).
* **1 Single Multi-Stop Rider** dispatched with dual-zone thermal bags.

```mermaid
flowchart TD
    subgraph CustomerAction ["Customer Action"]
        Cart["Unified Cart: Wazwan from Outlet A + Sweets from Outlet B"]
        Checkout["Single Checkout & Single Delivery Fee"]
    end

    subgraph SplitEngine ["Split Engine & Kitchen Dispatch"]
        MasterOrder["Master Order #MC-5177"]
        SubOrderA["Sub-Ticket 1 -> Outlet A Kitchen"]
        SubOrderB["Sub-Ticket 2 -> Outlet B Kitchen"]
    end

    subgraph MultiStopRider ["Multi-Stop Consolidated Rider"]
        Rider["Rider Ramesh Kumar (Honda Activa)"]
        Stop1["Stop 1 (Pickup): Outlet A"]
        Stop2["Stop 2 (Pickup): Outlet B"]
        Dropoff["Final Stop (Dropoff): Customer Doorstep"]
    end

    Cart --> Checkout --> MasterOrder
    MasterOrder --> SubOrderA
    MasterOrder --> SubOrderB
    MasterOrder --> Rider
    Rider --> Stop1 --> Stop2 --> Dropoff
```

---

## 🗺️ Universal Pan-India Geographic Architecture

### 1. Top of India to Bottom of India (Kashmir to Kanyakumari)
* 🏔️ **North & Top of India**: 
  * **Srinagar, Kashmir**: *Ahdoos Royal Kashmiri Wazwan (Est. 1918)* (Rogan Josh, Gushtaba, Kahwa)
  * **Amritsar, Punjab**: *Kesar Da Dhaba (Est. 1916)* (Dal Makhani, Amritsari Kulcha, Lassi)
  * **Shimla & Manali, Himachal Pradesh**: *The Mall Road Alpine Bakery & Cafe*
  * **Delhi NCR & Varanasi, UP**: Old Delhi Chandni Chowk & Ghats
* 🌴 **South & Bottom of India**:
  * **Kanyakumari, Tamil Nadu**: *Cape Comorin Sea View Tiffin & Seafood* (Neer Dosa, Meen Curry)
  * **Kochi & Alleppey, Kerala**: *Fort Kochi Heritage Spice & Backwater Cafe*
  * **Bengaluru, Chennai, Hyderabad**: Indiranagar Hub, Marina Filter Coffee, Dum Biryani
* 🏜️ **West India**: Jaipur (*Chokhi Dhani*), Mumbai, Ahmedabad
* 🍵 **East & North-East**: Guwahati & Assam (*Brahmaputra Tea*), Kolkata (*Flurys*)
* 🌾 **Central & Rural Heartlands**: Grand Trunk Road Murthal Dhaba & Kisan Marts

### 2. Universal Indian Town & Village Synthesizer (100% India Coverage)
Type **ANY** village, town, or district in India (e.g. *Rampur, Dharmapuri, Alappuzha, Chopda, Baramulla*):
* The engine instantly generates a local 4-outlet Food Hub:
  1. **Highway Dhaba & Family Restaurant** (Tandoor, Curries, Thali)
  2. **Halwai & Chai Chowk** (Hot Samosas, Jalebi with Rabri)
  3. **Village Kisan Mart & Fresh Dairy** (Malai Paneer, Cold-Pressed Mustard Oil)
  4. **Kulhad Chai & Snacks Adda** (Elaichi Adrak Chai, Bun Maska)

---

## 🚀 Key Modules Included

1. **OmniCart Multi-Restaurant Consumer App**: Cross-store shopping, category tabs, pure veg toggle, delivery savings pill.
2. **Multi-Stop Live Rider Tracker**: Real-time stop sequence visualization with interactive `"Advance Rider to Next Stop"` evaluation trigger.
3. **Omnichannel Aggregator Simulator**: Live simulated order triggers for Swiggy, Zomato, and Direct channels.
4. **Kitchen Display System (KDS)**: Real-time ticket management with item-level checklist status (`PREPARING` $\rightarrow$ `READY` $\rightarrow$ `COLLECTED`).
5. **POS Billing Terminal**: Dine-in, Takeaway, and Aggregator tab management with instant KOT printing.
6. **Live Analytics Dashboard**: Revenue breakdown, Swiggy/Zomato commission leakage analysis, rider dispatch metrics.

---

## 💻 Tech Stack

* **Frontend**: React 19, Vite, Tailwind CSS, Lucide React, Socket.io-client.
* **Backend**: Node.js, Express, Socket.io, Mongoose (MongoDB with auto in-memory fallback).
* **DevOps**: Docker, Cloudflare Tunnel, Render.com blueprint (`render.yaml`).

---

## 🛠️ Quick Start

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/omnicart-food-system.git
cd omnicart-food-system
```

### 2. Install dependencies
```bash
npm run install:all
```

### 3. Run development servers
```bash
npm run dev
```
* **Frontend**: `http://localhost:5173`
* **Backend**: `http://localhost:5000`

### 4. Build and run production
```bash
npm run build
npm start
```
The entire application will run unified on `http://localhost:5000`.

---

## 📄 License
This project is licensed under the MIT License.
