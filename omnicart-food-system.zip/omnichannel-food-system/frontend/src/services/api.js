import { io } from 'socket.io-client';

const isDevVite = typeof window !== 'undefined' && window.location.port === '5173';
const SERVER_URL = import.meta.env.VITE_API_URL || (isDevVite ? 'http://localhost:5000' : '');

const API_BASE = SERVER_URL ? `${SERVER_URL}/api` : '/api';
export const socket = io(SERVER_URL || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5000'));

export const api = {
  // Orders
  getOrders: async (filters = {}) => {
    const params = new URLSearchParams(filters);
    const res = await fetch(`${API_BASE}/orders?${params}`);
    return res.json();
  },
  
  getOrderById: async (id) => {
    const res = await fetch(`${API_BASE}/orders/${id}`);
    return res.json();
  },

  createDirectOrder: async (data) => {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  updateOrderStatus: async (id, status, extra = {}) => {
    const res = await fetch(`${API_BASE}/orders/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, ...extra })
    });
    return res.json();
  },

  updateItemStatus: async (orderId, itemIndex, itemStatus) => {
    const res = await fetch(`${API_BASE}/orders/${orderId}/item-status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ itemIndex, itemStatus })
    });
    return res.json();
  },

  // Menu
  getMenu: async () => {
    const res = await fetch(`${API_BASE}/menu`);
    return res.json();
  },

  toggleItemAvailability: async (id, isAvailable) => {
    const res = await fetch(`${API_BASE}/menu/${id}/toggle`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isAvailable })
    });
    return res.json();
  },

  // Simulator
  triggerSimulatedOrder: async (channel, customerName) => {
    const res = await fetch(`${API_BASE}/simulator/trigger-order`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channel, customerName })
    });
    return res.json();
  },

  triggerRiderArrival: async (orderId) => {
    const res = await fetch(`${API_BASE}/simulator/trigger-rider-arrival`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId })
    });
    return res.json();
  },

  getSimulatorLogs: async () => {
    const res = await fetch(`${API_BASE}/simulator/logs`);
    return res.json();
  },

  // Analytics
  getAnalyticsSummary: async () => {
    const res = await fetch(`${API_BASE}/analytics/summary`);
    return res.json();
  },

  // OmniCart Multi-Restaurant Hub
  getHubZones: async () => {
    const res = await fetch(`${API_BASE}/hub/zones`);
    return res.json();
  },

  getHubCities: async () => {
    const res = await fetch(`${API_BASE}/hub/cities`);
    return res.json();
  },

  getHubRestaurants: async (params = {}) => {
    // Support both object params { city, zone, query } and legacy string city
    let queryParams = new URLSearchParams();
    if (typeof params === 'string') {
      if (params && params !== 'ALL') queryParams.append('city', params);
    } else if (params && typeof params === 'object') {
      if (params.city && params.city !== 'ALL') queryParams.append('city', params.city);
      if (params.zone && params.zone !== 'ALL') queryParams.append('zone', params.zone);
      if (params.query) queryParams.append('q', params.query);
    }
    const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
    const res = await fetch(`${API_BASE}/hub/restaurants${queryString}`);
    return res.json();
  },

  createMultiOrder: async (orderData) => {
    const res = await fetch(`${API_BASE}/hub/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    });
    return res.json();
  },

  getMultiOrders: async () => {
    const res = await fetch(`${API_BASE}/hub/orders`);
    return res.json();
  },

  advanceRouteStop: async (orderId) => {
    const res = await fetch(`${API_BASE}/hub/orders/${orderId}/advance-stop`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' }
    });
    return res.json();
  }
};

