import React, { useState, useEffect } from 'react';
import { socket } from './services/api';
import OmniCartApp from './views/OmniCartApp';
import PosTerminal from './views/PosTerminal';
import KitchenDisplay from './views/KitchenDisplay';
import CustomerStore from './views/CustomerStore';
import AggregatorSimulator from './views/AggregatorSimulator';
import AnalyticsDashboard from './views/AnalyticsDashboard';
import MenuManager from './views/MenuManager';
import { 
  Store, ChefHat, ShoppingBag, Zap, 
  BarChart3, Utensils, Wifi, WifiOff, Sparkles
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('omnicart');
  const [isConnected, setIsConnected] = useState(socket.connected);

  useEffect(() => {
    const onConnect = () => setIsConnected(true);
    const onDisconnect = () => setIsConnected(false);

    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);

    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
    };
  }, []);

  const navItems = [
    { id: 'omnicart', label: '🛒 OmniCart (Multi-Store)', icon: Sparkles, isHighlight: true },
    { id: 'pos', label: 'POS Terminal', icon: Store, badge: 'Live Dispatch' },
    { id: 'kds', label: 'Kitchen Display', icon: ChefHat, badge: 'Chefs' },
    { id: 'customer', label: 'Single Storefront', icon: ShoppingBag, badge: 'Direct' },
    { id: 'simulator', label: 'Swiggy & Zomato Sandbox', icon: Zap, badge: 'Aggregators' },
    { id: 'analytics', label: 'Analytics & Ledger', icon: BarChart3, badge: 'Margins' },
    { id: 'menu', label: 'Menu & 86-ing', icon: Utensils, badge: 'Catalog' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-100 font-sans">
      {/* Global Navigation Header */}
      <header className="bg-slate-900 text-white sticky top-0 z-40 shadow-lg border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4 py-3">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center font-black text-slate-950 shadow-md">
              🍔
            </div>
            <div>
              <div className="text-sm font-black tracking-tight leading-none text-white flex items-center gap-2">
                OMNICHANNEL RESTAURANT SYSTEM
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500 text-slate-950">
                  MAJOR PROJECT
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                <span>Unified POS • KDS • Swiggy & Zomato Bridge</span>
              </div>
            </div>
          </div>

          {/* WebSocket Status Indicator */}
          <div className="flex items-center gap-2 text-xs">
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full font-mono font-medium ${
              isConnected 
                ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800' 
                : 'bg-rose-950/80 text-rose-400 border border-rose-800'
            }`}>
              {isConnected ? <Wifi className="w-3.5 h-3.5 text-emerald-400 animate-pulse" /> : <WifiOff className="w-3.5 h-3.5" />}
              <span>{isConnected ? 'Realtime Socket: Connected' : 'Connecting to Server...'}</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex overflow-x-auto border-t border-slate-800">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`py-3 px-4 flex items-center gap-2 border-b-2 font-bold text-xs whitespace-nowrap transition-all ${
                  isActive
                    ? 'border-amber-400 text-amber-400 bg-slate-800/60'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.id === 'simulator' && (
                  <span className="text-[10px] bg-[#FC8019] text-white px-1.5 py-0.2 rounded font-black">
                    Swiggy/Zomato
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main View Router */}
      <main className="flex-1 flex flex-col">
        {activeTab === 'omnicart' && <OmniCartApp />}
        {activeTab === 'pos' && <PosTerminal />}
        {activeTab === 'kds' && <KitchenDisplay />}
        {activeTab === 'customer' && <CustomerStore />}
        {activeTab === 'simulator' && <AggregatorSimulator />}
        {activeTab === 'analytics' && <AnalyticsDashboard />}
        {activeTab === 'menu' && <MenuManager />}
      </main>
    </div>
  );
}
