import React, { useState, useEffect } from 'react';
import { api, socket } from '../services/api';
import { 
  ShoppingBag, Plus, Minus, CheckCircle, Clock, 
  MapPin, Phone, User, ArrowRight, Sparkles, AlertCircle,
  Bike, Store
} from 'lucide-react';

export default function CustomerStore() {
  const [menu, setMenu] = useState([]);
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [vegOnly, setVegOnly] = useState(false);
  const [cart, setCart] = useState({});
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [orderType, setOrderType] = useState('DELIVERY'); // 'DELIVERY' | 'PICKUP'

  // Customer details
  const [customerName, setCustomerName] = useState('Bhanu Prakash');
  const [customerPhone, setCustomerPhone] = useState('+91 98765 43210');
  const [customerAddress, setCustomerAddress] = useState('Flat 302, Palm Grove Apts, Indiranagar, Bengaluru');

  // Active tracking order
  const [activeOrder, setActiveOrder] = useState(null);

  useEffect(() => {
    fetchMenu();

    const handleStatusUpdated = (payload) => {
      setActiveOrder(prev => {
        if (prev && (prev.id === payload.orderId || prev.orderNumber === payload.orderNumber)) {
          return payload.order;
        }
        return prev;
      });
    };

    const handleRiderUpdated = (payload) => {
      setActiveOrder(prev => {
        if (prev && (prev.id === payload.orderId || prev.orderNumber === payload.orderNumber)) {
          return { ...prev, rider: payload.rider };
        }
        return prev;
      });
    };

    const handleInventorySync = (payload) => {
      setMenu(prev => prev.map(item => 
        item.id === payload.item.id ? { ...item, isAvailable: payload.isAvailable } : item
      ));
    };

    socket.on('order_status_updated', handleStatusUpdated);
    socket.on('rider_status_updated', handleRiderUpdated);
    socket.on('inventory_synced', handleInventorySync);

    return () => {
      socket.off('order_status_updated', handleStatusUpdated);
      socket.off('rider_status_updated', handleRiderUpdated);
      socket.off('inventory_synced', handleInventorySync);
    };
  }, []);

  const fetchMenu = async () => {
    try {
      const res = await api.getMenu();
      if (res.success) setMenu(res.items);
    } catch (e) {
      console.error(e);
    }
  };

  const categories = ['ALL', ...new Set(menu.map(i => i.category))];

  const filteredMenu = menu.filter(item => {
    if (activeCategory !== 'ALL' && item.category !== activeCategory) return false;
    if (vegOnly && !item.isVeg) return false;
    return true;
  });

  const addToCart = (item) => {
    setCart(prev => ({
      ...prev,
      [item.id]: {
        item,
        quantity: (prev[item.id]?.quantity || 0) + 1
      }
    }));
  };

  const removeFromCart = (itemId) => {
    setCart(prev => {
      const next = { ...prev };
      if (next[itemId].quantity > 1) {
        next[itemId].quantity -= 1;
      } else {
        delete next[itemId];
      }
      return next;
    });
  };

  const cartItemsArray = Object.values(cart);
  const cartSubtotal = cartItemsArray.reduce((acc, c) => acc + (c.item.price * c.quantity), 0);
  const cartTaxes = +(cartSubtotal * 0.05).toFixed(2);
  const deliveryFee = (orderType === 'DELIVERY' && cartSubtotal > 0) ? 30 : 0;
  const cartTotal = +(cartSubtotal + cartTaxes + deliveryFee).toFixed(2);
  const cartItemCount = cartItemsArray.reduce((acc, c) => acc + c.quantity, 0);

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    if (cartItemsArray.length === 0) return;

    setSubmitting(true);
    try {
      const payload = {
        orderType,
        customer: {
          name: customerName,
          phone: customerPhone,
          address: orderType === 'PICKUP' 
            ? 'Store Pickup Counter (Spice Garden Bistro - Indiranagar)' 
            : customerAddress
        },
        items: cartItemsArray.map(c => ({
          menuItemId: c.item.id,
          name: c.item.name,
          quantity: c.quantity,
          unitPrice: c.item.price
        }))
      };

      const res = await api.createDirectOrder(payload);
      if (res.success) {
        setActiveOrder(res.order);
        setCart({});
        setIsCartOpen(false);
      }
    } catch (err) {
      alert(`Order placement failed: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  // Status Stepper Helper
  const getStepIndex = (status) => {
    switch (status) {
      case 'PLACED': return 1;
      case 'ACCEPTED': return 2;
      case 'IN_KITCHEN': return 3;
      case 'FOOD_READY': return 4;
      case 'OUT_FOR_DELIVERY': return 5;
      case 'DELIVERED': return 6;
      default: return 1;
    }
  };

  return (
    <div className="flex-1 bg-slate-50 min-h-screen">
      {/* Restaurant Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white py-10 px-6 shadow-md relative overflow-hidden">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold mb-3 border border-emerald-400/30">
              <Sparkles className="w-3.5 h-3.5" />
              Direct Online Ordering (0% Commission Platform)
            </div>
            <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Spice Garden Bistro</h1>
            <p className="text-slate-300 text-sm mt-1 max-w-xl">
              Authentic Indian gourmet dining & artisanal tandoor delicacies delivered piping hot to your doorstep.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsCartOpen(true)}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-5 py-3 rounded-xl flex items-center gap-2 shadow-lg transition-all"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>Cart ({cartItemCount})</span>
              {cartItemCount > 0 && (
                <span className="bg-slate-950 text-white text-xs px-2 py-0.5 rounded-full font-mono ml-1">
                  ₹{cartTotal}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Active Order Live Tracker (if exists) */}
        {activeOrder && (
          <div className="bg-white rounded-2xl p-6 shadow-md border-2 border-emerald-400 mb-8 animate-fade-in">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-md">
                    {activeOrder.orderType === 'PICKUP' ? '🛍️ Self-Pickup / Takeaway Order' : '🟢 Live Home Delivery Tracking'}
                  </span>
                  {activeOrder.pickupCode && (
                    <span className="text-xs font-mono font-black bg-indigo-600 text-white px-2.5 py-1 rounded-md shadow-sm">
                      Token: {activeOrder.pickupCode}
                    </span>
                  )}
                </div>
                <h2 className="text-xl font-black text-slate-900 mt-1">
                  Order {activeOrder.orderNumber}
                </h2>
                <div className="text-xs text-slate-500">
                  {activeOrder.orderType === 'PICKUP' 
                    ? 'Estimated Pickup Time: 15 - 20 mins' 
                    : 'Estimated Delivery: 25 - 35 mins'}
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400">Total Paid</div>
                <div className="text-xl font-extrabold text-slate-900 font-mono">
                  ₹{activeOrder.financials?.grandTotal}
                </div>
                <div className="text-[11px] text-emerald-600 font-semibold mt-0.5">
                  {activeOrder.orderType === 'PICKUP' ? 'Zero Delivery Charge' : 'Direct Home Delivery'}
                </div>
              </div>
            </div>

            {/* Stepper */}
            <div className="py-6">
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 relative">
                {(activeOrder.orderType === 'PICKUP' ? [
                  { title: 'Order Placed', desc: 'Sent to counter', step: 1 },
                  { title: 'Accepted', desc: 'Prep time set', step: 2 },
                  { title: 'Cooking', desc: 'In Kitchen KDS', step: 3 },
                  { title: 'Ready at Counter', desc: 'Ready for Pickup!', step: 4 },
                  { title: 'Picked Up', desc: 'Enjoy your meal!', step: 5 },
                ] : [
                  { title: 'Order Placed', desc: 'Sent to restaurant', step: 1 },
                  { title: 'Accepted', desc: 'Prep time allotted', step: 2 },
                  { title: 'Cooking', desc: 'In Kitchen KDS', step: 3 },
                  { title: 'Packed & Ready', desc: 'Waiting for rider', step: 4 },
                  { title: 'Delivered', desc: 'Enjoy your food!', step: 5 },
                ]).map((s, idx) => {
                  const currentStep = getStepIndex(activeOrder.status);
                  const isDone = currentStep >= s.step;
                  const isCurrent = currentStep === s.step;

                  return (
                    <div key={idx} className="flex flex-col items-center text-center">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm mb-2 transition-all ${
                        isDone 
                          ? 'bg-emerald-600 text-white shadow-md shadow-emerald-200' 
                          : 'bg-slate-200 text-slate-500'
                      } ${isCurrent ? 'ring-4 ring-emerald-300 animate-pulse' : ''}`}>
                        {isDone ? <CheckCircle className="w-5 h-5" /> : s.step}
                      </div>
                      <div className={`text-xs font-bold leading-tight ${isCurrent ? 'text-emerald-700' : 'text-slate-800'}`}>
                        {s.title}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{s.desc}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-slate-50 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                {activeOrder.orderType === 'PICKUP' ? (
                  <>
                    <Store className="w-4 h-4 text-emerald-600" />
                    <span>Self-Pickup at: <strong>Spice Garden Bistro Front Counter (Show Code: {activeOrder.pickupCode || 'PK-89'})</strong></span>
                  </>
                ) : (
                  <>
                    <MapPin className="w-4 h-4 text-emerald-600" />
                    <span>Delivering to: <strong>{activeOrder.customer?.address}</strong></span>
                  </>
                )}
              </div>
              <button 
                onClick={() => setActiveOrder(null)}
                className="text-xs text-slate-400 hover:text-slate-600 font-semibold underline"
              >
                Dismiss Tracker
              </button>
            </div>
          </div>
        )}

        {/* Categories Bar & Filters */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeCategory === cat
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Veg Only Toggle */}
          <button
            onClick={() => setVegOnly(!vegOnly)}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 border transition-all ${
              vegOnly 
                ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm' 
                : 'bg-white border-slate-200 text-slate-600'
            }`}
          >
            <span className="w-3 h-3 rounded-full border-2 border-emerald-600 flex items-center justify-center p-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
            </span>
            Pure Veg Only
          </button>
        </div>

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMenu.map(item => {
            const quantityInCart = cart[item.id]?.quantity || 0;

            return (
              <div 
                key={item.id}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="h-44 w-full overflow-hidden bg-slate-100 relative">
                    <img 
                      src={item.imageUrl} 
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {!item.isAvailable && (
                      <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center text-white font-bold text-sm">
                        Temporarily Out of Stock (86-ed)
                      </div>
                    )}
                    <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-sm px-2.5 py-1 rounded-md text-[11px] font-bold shadow-sm flex items-center gap-1.5">
                      <span className={`w-2.5 h-2.5 rounded-full ${item.isVeg ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                      {item.isVeg ? 'Veg' : 'Non-Veg'}
                    </div>
                  </div>

                  <div className="p-4">
                    <div className="flex justify-between items-start gap-2">
                      <h3 className="font-bold text-slate-900 text-base leading-snug">{item.name}</h3>
                      <span className="font-mono font-extrabold text-slate-900 text-base">₹{item.price}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="p-4 pt-0">
                  {item.isAvailable ? (
                    quantityInCart === 0 ? (
                      <button
                        onClick={() => addToCart(item)}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                      >
                        <Plus className="w-4 h-4" />
                        Add to Order
                      </button>
                    ) : (
                      <div className="flex items-center justify-between bg-slate-100 rounded-xl p-1">
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="w-8 h-8 rounded-lg bg-white text-slate-800 font-bold flex items-center justify-center shadow-sm"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="font-bold font-mono text-sm text-slate-900">{quantityInCart}</span>
                        <button
                          onClick={() => addToCart(item)}
                          className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-bold flex items-center justify-center shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )
                  ) : (
                    <button
                      disabled
                      className="w-full bg-slate-100 text-slate-400 font-bold py-2 rounded-xl text-xs cursor-not-allowed"
                    >
                      Unavailable
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-end">
          <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl p-6 overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-600" />
                Your Direct Order
              </h2>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="text-slate-400 hover:text-slate-800 text-lg font-bold p-1"
              >
                ✕
              </button>
            </div>

            {cartItemsArray.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-400 py-20">
                <ShoppingBag className="w-12 h-12 mb-3 stroke-1" />
                <p className="font-semibold text-slate-600">Your basket is currently empty</p>
                <p className="text-xs mt-1">Explore our chef special delicacies and add dishes.</p>
              </div>
            ) : (
              <form onSubmit={handlePlaceOrder} className="flex-1 flex flex-col justify-between mt-4">
                <div className="space-y-4">
                  {/* Cart Items */}
                  <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                    {cartItemsArray.map(({ item, quantity }) => (
                      <div key={item.id} className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs">
                        <div className="truncate max-w-[180px]">
                          <div className="font-bold text-slate-800 truncate">{item.name}</div>
                          <div className="text-slate-400 font-mono">₹{item.price} each</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button 
                            type="button"
                            onClick={() => removeFromCart(item.id)} 
                            className="p-1 rounded bg-white border border-slate-200"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-bold font-mono text-slate-900">{quantity}</span>
                          <button 
                            type="button"
                            onClick={() => addToCart(item)} 
                            className="p-1 rounded bg-white border border-slate-200"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                          <span className="font-bold font-mono text-slate-900 w-12 text-right">
                            ₹{item.price * quantity}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Fulfillment Mode: Delivery vs Self-Pickup */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                      Choose Order Fulfillment
                    </label>
                    <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200">
                      <button
                        type="button"
                        onClick={() => setOrderType('DELIVERY')}
                        className={`py-2 px-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                          orderType === 'DELIVERY'
                            ? 'bg-white text-emerald-800 shadow-sm border border-slate-200'
                            : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        <Bike className="w-3.5 h-3.5" />
                        <span>Delivery (₹30)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setOrderType('PICKUP')}
                        className={`py-2 px-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                          orderType === 'PICKUP'
                            ? 'bg-emerald-600 text-white shadow-sm'
                            : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        <Store className="w-3.5 h-3.5" />
                        <span>Self-Pickup (FREE)</span>
                      </button>
                    </div>
                  </div>

                  {/* Customer Contact & Address / Pickup Location */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {orderType === 'PICKUP' ? 'Self-Pickup Contact Info' : 'Delivery Details'}
                    </h4>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-500 block mb-1">Your Full Name</label>
                      <input 
                        type="text" 
                        required 
                        value={customerName} 
                        onChange={e => setCustomerName(e.target.value)}
                        className="w-full text-xs p-2 rounded-lg border border-slate-300 focus:outline-emerald-500" 
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-500 block mb-1">Phone Number</label>
                      <input 
                        type="text" 
                        required 
                        value={customerPhone} 
                        onChange={e => setCustomerPhone(e.target.value)}
                        className="w-full text-xs p-2 rounded-lg border border-slate-300 focus:outline-emerald-500" 
                      />
                    </div>

                    {orderType === 'DELIVERY' ? (
                      <div>
                        <label className="text-[11px] font-semibold text-slate-500 block mb-1">Delivery Address</label>
                        <textarea 
                          rows={2} 
                          required 
                          value={customerAddress} 
                          onChange={e => setCustomerAddress(e.target.value)}
                          className="w-full text-xs p-2 rounded-lg border border-slate-300 focus:outline-emerald-500" 
                        />
                      </div>
                    ) : (
                      <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-900 space-y-1">
                        <div className="font-bold flex items-center gap-1.5">
                          <Store className="w-4 h-4 text-emerald-700" />
                          <span>Restaurant Pickup Counter</span>
                        </div>
                        <p className="text-[11px] text-emerald-800">
                          📍 Spice Garden Bistro, 12th Main, Indiranagar, Bengaluru
                        </p>
                        <p className="text-[10px] text-emerald-700 font-semibold pt-0.5">
                          ⚡ Ready in ~15 mins • Show your token at the counter to pick up!
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Bill Summary */}
                  <div className="bg-slate-100 p-3.5 rounded-xl text-xs space-y-1.5 font-mono">
                    <div className="flex justify-between text-slate-600">
                      <span>Item Subtotal</span>
                      <span>₹{cartSubtotal}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>GST (5%)</span>
                      <span>₹{cartTaxes}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Delivery Fee</span>
                      <span>{orderType === 'PICKUP' ? <strong className="text-emerald-700">₹0 (FREE Pickup)</strong> : `₹${deliveryFee}`}</span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-900 border-t border-slate-200 pt-1.5 text-sm">
                      <span>Grand Total</span>
                      <span>₹{cartTotal}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg transition-colors"
                  >
                    <span>{submitting ? 'Placing Order...' : `Pay & Place Order (₹${cartTotal})`}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className="text-[11px] text-center text-slate-400 mt-2">
                    Direct restaurant order • No third-party platform fee
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
