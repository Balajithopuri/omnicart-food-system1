import React, { useState, useEffect } from 'react';
import { api, socket } from '../services/api';
import { 
  ShoppingBag, Plus, Minus, CheckCircle, Clock, 
  MapPin, Bike, Sparkles, Store, ArrowRight, Zap, 
  Navigation, CheckCircle2, AlertCircle, TrendingDown, Star,
  Search, ArrowLeft, Coffee, UtensilsCrossed, IceCream, ShoppingCart
} from 'lucide-react';

export default function OmniCartApp() {
  const [restaurants, setRestaurants] = useState([]);
  const [cities, setCities] = useState([]);
  const [zones, setZones] = useState([]);
  const [selectedZone, setSelectedZone] = useState('ALL');
  const [selectedCity, setSelectedCity] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Universal Indian Location Search (City, Town, Village, District)
  const [locationInput, setLocationInput] = useState('');
  const [activeLocationQuery, setActiveLocationQuery] = useState('');
  
  // Selected single restaurant view (null means Hub Grid view)
  const [selectedStore, setSelectedStore] = useState(null);
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [vegOnly, setVegOnly] = useState(false);

  // Cart & Order state
  const [cart, setCart] = useState({});
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeOrder, setActiveOrder] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Customer form
  const [name, setName] = useState('Bhanu Prakash');
  const [phone, setPhone] = useState('+91 98765 43210');
  const [address, setAddress] = useState('Direct Pan-India Delivery Address');

  const fetchHub = async () => {
    try {
      const [restRes, cityRes, zoneRes] = await Promise.all([
        api.getHubRestaurants({
          city: selectedCity !== 'ALL' ? selectedCity : '',
          zone: selectedZone !== 'ALL' ? selectedZone : '',
          query: activeLocationQuery
        }),
        api.getHubCities(),
        api.getHubZones()
      ]);
      if (restRes.success) setRestaurants(restRes.restaurants);
      if (cityRes.success) setCities(cityRes.cities);
      if (zoneRes.success) setZones(zoneRes.zones);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchHub();
  }, [selectedCity, selectedZone, activeLocationQuery]);

  useEffect(() => {
    const handleRouteUpdated = (payload) => {
      setActiveOrder(prev => {
        if (prev && (prev.id === payload.orderId || prev.orderNumber === payload.orderNumber)) {
          return payload.order;
        }
        return prev;
      });
    };

    socket.on('multi_route_updated', handleRouteUpdated);
    return () => {
      socket.off('multi_route_updated', handleRouteUpdated);
    };
  }, []);

  const addToCart = (item) => {
    setCart(prev => ({
      ...prev,
      [item.id]: {
        item,
        quantity: (prev[item.id]?.quantity || 0) + 1
      }
    }));
  };

  const removeFromCart = (itemId) => {
    setCart(prev => {
      const next = { ...prev };
      if (next[itemId].quantity > 1) {
        next[itemId].quantity -= 1;
      } else {
        delete next[itemId];
      }
      return next;
    });
  };

  const cartItems = Object.values(cart);
  const uniqueRestaurants = [...new Set(cartItems.map(c => c.item.restaurantName))];
  const itemsTotal = cartItems.reduce((sum, c) => sum + (c.item.price * c.quantity), 0);
  const taxes = +(itemsTotal * 0.05).toFixed(2);

  // Delivery fee logic: Swiggy charges ₹40 per restaurant (3 stores = ₹120!)
  const swiggyDeliveryEquivalent = uniqueRestaurants.length * 40;
  // OmniCart multi-stop fee: Base ₹35 + ₹15 per extra store
  const multiStopDeliveryFee = uniqueRestaurants.length > 0 ? (35 + (uniqueRestaurants.length - 1) * 15) : 0;
  const deliverySavings = Math.max(0, swiggyDeliveryEquivalent - multiStopDeliveryFee);
  const grandTotal = +(itemsTotal + taxes + multiStopDeliveryFee).toFixed(2);

  const handleLocationSearch = (e) => {
    e.preventDefault();
    if (!locationInput.trim()) return;
    setActiveLocationQuery(locationInput.trim());
    setSelectedCity('ALL');
    setSelectedZone('ALL');
    setSelectedStore(null);
  };

  const handleResetLocation = () => {
    setLocationInput('');
    setActiveLocationQuery('');
    setSelectedCity('ALL');
    setSelectedZone('ALL');
    setSelectedStore(null);
  };

  const handleSelectQuickLocation = (cityId) => {
    setLocationInput('');
    setActiveLocationQuery('');
    setSelectedZone('ALL');
    setSelectedCity(cityId);
    setSelectedStore(null);
  };

  const handleSelectZone = (zoneId) => {
    setLocationInput('');
    setActiveLocationQuery('');
    setSelectedCity('ALL');
    setSelectedZone(zoneId);
    setSelectedStore(null);
  };

  const handleCheckout = async (e) => {
    e.preventDefault();
    if (cartItems.length === 0) return;

    setSubmitting(true);
    try {
      const payload = {
        customer: { name, phone, address },
        items: cartItems.map(c => ({
          id: c.item.id,
          name: c.item.name,
          price: c.item.price,
          quantity: c.quantity,
          restaurantId: c.item.restaurantId,
          restaurantName: c.item.restaurantName
        }))
      };

      const res = await api.createMultiOrder(payload);
      if (res.success) {
        setActiveOrder(res.order);
        setCart({});
        setIsCartOpen(false);
      }
    } catch (err) {
      alert(`Checkout error: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAdvanceStop = async () => {
    if (!activeOrder) return;
    try {
      const res = await api.advanceRouteStop(activeOrder.id);
      if (res.success) setActiveOrder(res.order);
    } catch (err) {
      alert(`Error advancing route: ${err.message}`);
    }
  };

  const filteredHubRestaurants = restaurants.filter(r => {
    if (typeFilter !== 'ALL' && r.outletType !== typeFilter) return false;
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      const matchesStore = r.name.toLowerCase().includes(query) || r.cuisine.toLowerCase().includes(query);
      const matchesDish = r.menu.some(d => d.name.toLowerCase().includes(query) || d.category.toLowerCase().includes(query));
      return matchesStore || matchesDish;
    }
    return true;
  });

  const isDynamicCluster = restaurants.some(r => r.zone === 'DYNAMIC');
  let locationBadge = '🇮🇳 Pan-India Food Network (Top to Bottom)';
  let locationTitle = 'Explore All India Iconic Food Hubs & Outlets';
  let locationSubtitle = 'Order from multiple authentic restaurants, highway dhabas, cafes, and bakeries across India in 1 single cart!';

  if (activeLocationQuery) {
    locationBadge = isDynamicCluster ? `🌾 Dynamic Town/Village Cluster: ${activeLocationQuery}` : `📍 Location Hub: ${activeLocationQuery}`;
    locationTitle = `${activeLocationQuery} Local Food Hub`;
    locationSubtitle = isDynamicCluster
      ? `Real-time town & village cluster generated for "${activeLocationQuery}": Highway Dhaba, Halwai & Chai Chowk, Village Kisan Mart & Chai Adda live!`
      : `Showing authentic local food hubs and outlets serving in ${activeLocationQuery}`;
  } else if (selectedZone !== 'ALL') {
    const currentZone = zones.find(z => z.id === selectedZone);
    locationBadge = `${currentZone?.name || selectedZone} Hub`;
    locationTitle = `${currentZone?.name || selectedZone} Culinary Hubs`;
    locationSubtitle = `Specialties, regional cuisines & dhabas across ${currentZone?.tag || 'this zone of India'}`;
  } else if (selectedCity !== 'ALL') {
    const currentCity = cities.find(c => c.id === selectedCity);
    locationBadge = `📍 ${currentCity?.hubName || selectedCity}`;
    locationTitle = `${currentCity?.name || selectedCity} Food Hub`;
    locationSubtitle = `Famous regional food joints and heritage outlets in ${currentCity?.name || selectedCity}`;
  }

  return (
    <div className="flex-1 bg-slate-50 min-h-screen">
      {/* OmniCart Top Brand Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-rose-700 text-white py-8 px-6 shadow-md relative overflow-hidden">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-sm text-white text-xs font-bold mb-2.5 border border-white/30">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>THE OMNICART NETWORK • MULTI-STORE ORDERING</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-black tracking-tight leading-tight">
              One Cart. Multiple Outlets.
            </h1>
            <p className="text-amber-100 text-xs md:text-sm mt-1.5 max-w-2xl leading-relaxed">
              Order <strong>Dum Biryani</strong>, <strong>Woodfired Pizza</strong>, <strong>Cafe Lattes</strong>, and <strong>Desserts</strong> across multiple outlets in 1 single checkout with 1 consolidated rider!
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsCartOpen(true)}
              className="bg-white text-slate-900 hover:bg-amber-50 font-black px-6 py-3.5 rounded-2xl flex items-center gap-2.5 shadow-xl transition-all"
            >
              <ShoppingBag className="w-5 h-5 text-amber-600" />
              <span>OmniCart ({cartItems.reduce((a, b) => a + b.quantity, 0)})</span>
              {cartItems.length > 0 && (
                <span className="bg-amber-600 text-white text-xs px-2.5 py-1 rounded-full font-mono font-bold">
                  ₹{grandTotal}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Pan-India Geographic Zones & Universal Location Navigator */}
      <div className="bg-slate-900 border-b border-slate-800 px-6 py-3.5 text-white sticky top-14 z-30 shadow-xl space-y-3">
        {/* Zone Selector Strip */}
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 font-black text-amber-400">
            <MapPin className="w-4 h-4 text-rose-500 animate-bounce" />
            <span className="tracking-wide uppercase text-[11px]">Pan-India Coverage: Top to Bottom</span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {zones.map(z => (
              <button
                key={z.id}
                onClick={() => handleSelectZone(z.id)}
                className={`px-3 py-1.5 rounded-full font-bold text-xs transition-all flex items-center gap-1 ${
                  selectedZone === z.id && !activeLocationQuery && selectedCity === 'ALL'
                    ? 'bg-amber-500 text-slate-950 font-black shadow-md ring-2 ring-amber-300'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
                title={z.tag}
              >
                <span>{z.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Universal Location Search (Towns, Villages, Districts, Cities) & Quick Hubs */}
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3 pt-2.5 border-t border-slate-800">
          <form onSubmit={handleLocationSearch} className="flex-1 min-w-[320px] flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={locationInput}
                onChange={e => setLocationInput(e.target.value)}
                placeholder="Enter ANY Indian Village, Town, or City (e.g. Srinagar, Kanyakumari, Rampur, Alappuzha...)"
                className="w-full text-xs pl-8 pr-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <button
              type="submit"
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-3.5 py-2 rounded-xl font-black text-xs transition-all flex items-center gap-1 shadow-sm whitespace-nowrap"
            >
              <span>Locate Outlets</span>
            </button>
            {(activeLocationQuery || selectedCity !== 'ALL' || selectedZone !== 'ALL') && (
              <button
                type="button"
                onClick={handleResetLocation}
                className="text-slate-400 hover:text-white px-2 py-2 text-xs font-bold underline whitespace-nowrap"
              >
                Reset
              </button>
            )}
          </form>

          {/* Quick Hub Pills (Top to Bottom of India) */}
          <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
            <span className="text-slate-400 font-bold uppercase text-[10px] mr-1">Quick Hubs:</span>
            {cities.map(c => (
              <button
                key={c.id}
                onClick={() => handleSelectQuickLocation(c.id)}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all whitespace-nowrap ${
                  selectedCity === c.id && !activeLocationQuery
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>{c.name.split('(')[0].trim()}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Active Multi-Stop Live Tracker (if order active) */}
        {activeOrder && (
          <div className="bg-white rounded-3xl p-6 shadow-xl border-2 border-amber-400 mb-10 animate-fade-in">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black uppercase tracking-wider text-amber-800 bg-amber-100 px-3 py-1 rounded-full flex items-center gap-1.5">
                    <Bike className="w-4 h-4 text-amber-600" />
                    Multi-Stop Single Rider Dispatch
                  </span>
                  <span className="text-xs font-bold text-slate-400 font-mono">
                    {activeOrder.clusterName}
                  </span>
                </div>
                <h2 className="text-2xl font-black text-slate-900 mt-1">
                  Master Order {activeOrder.orderNumber}
                </h2>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-xs text-slate-400">Total Combined Bill</div>
                  <div className="text-2xl font-black text-slate-900 font-mono">
                    ₹{activeOrder.financials?.grandTotal}
                  </div>
                  <div className="text-xs font-bold text-emerald-600">
                    Saved ₹{activeOrder.financials?.deliverySavings} on delivery fees!
                  </div>
                </div>

                {activeOrder.status !== 'DELIVERED' && (
                  <button
                    onClick={handleAdvanceStop}
                    className="ml-3 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 animate-pulse"
                  >
                    <Navigation className="w-4 h-4" />
                    Advance Rider to Next Stop
                  </button>
                )}
              </div>
            </div>

            {/* Rider Identity Strip */}
            <div className="bg-slate-50 rounded-2xl p-4 my-4 flex flex-wrap items-center justify-between gap-4 border border-slate-200">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-amber-500 text-slate-950 font-black flex items-center justify-center text-lg shadow-md">
                  🛵
                </div>
                <div>
                  <div className="font-extrabold text-sm text-slate-900">
                    {activeOrder.multiStopRoute?.rider?.name}
                  </div>
                  <div className="text-xs text-slate-500 font-mono">
                    Vehicle: {activeOrder.multiStopRoute?.rider?.vehicle} • {activeOrder.multiStopRoute?.rider?.phone}
                  </div>
                </div>
              </div>
              <div className="text-xs font-bold bg-amber-100 text-amber-900 px-3 py-1.5 rounded-xl border border-amber-300">
                📦 {activeOrder.multiStopRoute?.rider?.bagType}
              </div>
            </div>

            {/* Route Timeline */}
            <div className="py-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                Rider Multi-Stop Pickup & Dropoff Route:
              </h3>
              <div className="relative border-l-2 border-slate-200 ml-4 pl-6 space-y-5">
                {activeOrder.multiStopRoute?.stops?.map((stop, idx) => {
                  const currentIdx = activeOrder.routeProgress || 0;
                  const isDone = currentIdx > idx;
                  const isCurrent = currentIdx === idx;

                  return (
                    <div key={idx} className="relative">
                      <div className={`absolute -left-[35px] top-0 w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                        isDone 
                          ? 'bg-emerald-600 text-white shadow-md' 
                          : isCurrent 
                            ? 'bg-amber-500 text-slate-950 ring-4 ring-amber-300 animate-pulse' 
                            : 'bg-slate-200 text-slate-500'
                      }`}>
                        {isDone ? <CheckCircle2 className="w-5 h-5" /> : stop.sequence}
                      </div>

                      <div className={`p-4 rounded-2xl border transition-all ${
                        isCurrent 
                          ? 'bg-amber-50/70 border-amber-300 shadow-sm' 
                          : isDone 
                            ? 'bg-slate-50 border-slate-200 opacity-75' 
                            : 'bg-white border-slate-100'
                      }`}>
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                              stop.type === 'PICKUP' ? 'bg-orange-100 text-orange-800' : 'bg-emerald-100 text-emerald-800'
                            }`}>
                              {stop.type === 'PICKUP' ? 'PICKUP STOP' : 'FINAL DELIVERY'}
                            </span>
                            <h4 className="font-extrabold text-sm text-slate-900 mt-1">{stop.title}</h4>
                            <p className="text-xs text-slate-500">{stop.location}</p>
                          </div>
                          <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                            isDone ? 'bg-emerald-100 text-emerald-800' :
                            isCurrent ? 'bg-amber-200 text-amber-900 font-black' :
                            'bg-slate-100 text-slate-500'
                          }`}>
                            {isDone ? '✓ Completed' : isCurrent ? '🛵 Rider Currently Here' : 'Upcoming'}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-slate-100 text-xs">
              <span className="text-slate-500">
                Delivering to: <strong>{activeOrder.customer?.address}</strong>
              </span>
              <button onClick={() => setActiveOrder(null)} className="text-slate-400 hover:text-slate-700 font-bold underline">
                Dismiss Tracker
              </button>
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW A: DEDICATED STORE MENU PAGE (When a Store is Selected)   */}
        {/* ------------------------------------------------------------- */}
        {selectedStore ? (
          <div className="space-y-8 animate-fade-in">
            {/* Back to Hub Button */}
            <button
              onClick={() => { setSelectedStore(null); setActiveCategory('ALL'); }}
              className="inline-flex items-center gap-2 text-xs font-extrabold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 px-4 py-2.5 rounded-xl shadow-sm transition-all"
            >
              <ArrowLeft className="w-4 h-4 text-amber-600" />
              <span>← Back to {selectedStore.cityName || 'Pan-India Food Network'} (All Stores)</span>
            </button>

            {/* Selected Store Banner */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 overflow-hidden relative">
              <div className="flex flex-wrap items-center justify-between gap-6">
                <div className="flex items-center gap-5">
                  <img 
                    src={selectedStore.image} 
                    alt={selectedStore.name} 
                    className="w-24 h-24 rounded-2xl object-cover shadow-md border border-slate-100"
                  />
                  <div>
                    <div className="flex items-center gap-2.5">
                      <span className="text-[11px] font-black uppercase px-2.5 py-0.5 rounded-md bg-amber-100 text-amber-900">
                        {selectedStore.typeLabel}
                      </span>
                      <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Star className="w-3.5 h-3.5 fill-emerald-600" /> {selectedStore.rating} ({selectedStore.reviewsCount})
                      </span>
                    </div>
                    <h2 className="text-2xl md:text-3xl font-black text-slate-900 mt-1">{selectedStore.name}</h2>
                    <p className="text-xs text-slate-500 mt-1">{selectedStore.tagline}</p>
                    <div className="text-xs text-slate-400 mt-2 flex flex-wrap items-center gap-3 font-medium">
                      <span>🍽️ {selectedStore.cuisine}</span>
                      <span>📍 {selectedStore.distance}</span>
                      <span>⏱️ ~{selectedStore.prepTimeMinutes} mins prep</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 p-4 rounded-2xl text-xs space-y-1">
                  <div className="font-extrabold text-amber-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    Multi-Store Enabled
                  </div>
                  <p className="text-amber-800 text-[11px] max-w-xs">
                    You can pick dishes here and also add items from other cafes or dessert stores in the same order!
                  </p>
                </div>
              </div>

              {/* Category Sub-Navigation for this store */}
              <div className="flex flex-wrap items-center justify-between gap-4 mt-8 pt-6 border-t border-slate-100">
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setActiveCategory('ALL')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                      activeCategory === 'ALL'
                        ? 'bg-slate-900 text-white shadow-sm'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    All Items ({selectedStore.menu.length})
                  </button>
                  {selectedStore.categories?.map(cat => {
                    const count = selectedStore.menu.filter(m => m.category === cat).length;
                    return (
                      <button
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                          activeCategory === cat
                            ? 'bg-amber-600 text-white shadow-sm'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {cat} ({count})
                      </button>
                    );
                  })}
                </div>

                {/* Pure Veg Toggle */}
                <button
                  onClick={() => setVegOnly(!vegOnly)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 border transition-all ${
                    vegOnly 
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700' 
                      : 'bg-white border-slate-200 text-slate-600'
                  }`}
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                  Pure Veg Only
                </button>
              </div>
            </div>

            {/* Complete Menu Grid of this store */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {selectedStore.menu
                .filter(item => {
                  if (activeCategory !== 'ALL' && item.category !== activeCategory) return false;
                  if (vegOnly && !item.isVeg) return false;
                  return true;
                })
                .map(dish => {
                  const qty = cart[dish.id]?.quantity || 0;

                  return (
                    <div 
                      key={dish.id}
                      className="bg-white rounded-3xl border border-slate-200 p-4 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="h-44 w-full rounded-2xl overflow-hidden bg-slate-100 mb-3 relative">
                          <img src={dish.image} alt={dish.name} className="w-full h-full object-cover" />
                          <div className="absolute top-2.5 left-2.5 bg-white/95 px-2.5 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1.5 shadow-sm">
                            <span className={`w-2 h-2 rounded-full ${dish.isVeg ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                            {dish.isVeg ? 'Veg' : 'Non-Veg'}
                          </div>
                          <div className="absolute top-2.5 right-2.5 bg-slate-900/80 backdrop-blur-sm text-white px-2 py-0.5 rounded-md text-[10px] font-bold">
                            {dish.category}
                          </div>
                        </div>

                        <div className="flex justify-between items-start gap-2">
                          <h4 className="font-extrabold text-base text-slate-900 leading-snug">{dish.name}</h4>
                          <span className="font-mono font-black text-slate-900 text-base">₹{dish.price}</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">
                          {dish.description}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-100">
                        {qty === 0 ? (
                          <button
                            onClick={() => addToCart(dish)}
                            className="w-full bg-slate-900 hover:bg-black text-white font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                          >
                            <Plus className="w-4 h-4 text-amber-400" />
                            Add to OmniCart
                          </button>
                        ) : (
                          <div className="flex items-center justify-between bg-slate-100 border border-slate-200 rounded-xl p-1">
                            <button
                              onClick={() => removeFromCart(dish.id)}
                              className="w-8 h-8 rounded-lg bg-white hover:bg-slate-50 text-slate-800 font-bold flex items-center justify-center shadow-sm"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="font-bold font-mono text-sm text-slate-900">{qty}</span>
                            <button
                              onClick={() => addToCart(dish)}
                              className="w-8 h-8 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold flex items-center justify-center shadow-sm"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        ) : (
          /* ------------------------------------------------------------- */
          /* VIEW B: HUB OUTLETS DIRECTORY (Restaurants, Cafes & Stores)    */
          /* ------------------------------------------------------------- */
          <div className="space-y-8 animate-fade-in">
            {/* Search Bar & Outlet Category Filters */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-amber-100 text-amber-900 text-[10px] font-black uppercase mb-1">
                    {locationBadge}
                  </div>
                  <h2 className="text-xl md:text-2xl font-black text-slate-900">
                    {locationTitle}
                  </h2>
                  <p className="text-xs text-slate-500 max-w-xl">
                    {locationSubtitle}
                  </p>
                </div>

                {/* Search input for dishes/cuisines */}
                <div className="relative min-w-[280px]">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Search dishes, Rogan Josh, Dosa, Chai, Biryani..."
                    className="w-full text-xs pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:outline-amber-500"
                  />
                </div>
              </div>

              {/* Dynamic Village / Town Cluster Banner */}
              {isDynamicCluster && (
                <div className="bg-amber-50 border border-amber-300 rounded-2xl p-3.5 flex items-center gap-3 animate-fade-in text-amber-900">
                  <span className="text-xl">🌾</span>
                  <div className="text-xs">
                    <strong className="font-extrabold">Instant Village/Town Food Cluster Online:</strong> All 4 core local food outlets (Highway Dhaba, Halwai & Chai Chowk, Village Kisan Mart, and Kulhad Chai Adda) are dynamically activated for this region. You can mix and match items into one order!
                  </div>
                </div>
              )}

              {/* Outlet Type Filter Tabs */}
              <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
                {[
                  { id: 'ALL', label: `All Outlets (${restaurants.length})`, icon: Store },
                  { id: 'RESTAURANT', label: '🍽️ Fine Restaurants & Dhabas', icon: UtensilsCrossed },
                  { id: 'CAFE', label: '☕ Specialty Cafes & Chai', icon: Coffee },
                  { id: 'DESSERT', label: '🍨 Halwai & Desserts', icon: IceCream },
                  { id: 'STORE', label: '🛒 Gourmet & Kisan Marts', icon: ShoppingCart },
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setTypeFilter(tab.id)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                      typeFilter === tab.id
                        ? 'bg-slate-900 text-white shadow-sm'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Outlets List */}
            <div className="space-y-8">
              {filteredHubRestaurants.map(rest => (
                <div 
                  key={rest.id} 
                  className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden p-6 hover:border-amber-400 transition-all"
                >
                  {/* Outlet Header */}
                  <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-100">
                    <div className="flex items-center gap-4">
                      <img 
                        src={rest.image} 
                        alt={rest.name}
                        className="w-16 h-16 rounded-2xl object-cover shadow-sm border border-slate-100"
                      />
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-200">
                            📍 {rest.cityName}
                          </span>
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                            {rest.zone === 'NORTH' ? '🏔️ North / Top' :
                             rest.zone === 'SOUTH' ? '🌴 South / Bottom' :
                             rest.zone === 'WEST' ? '🏜️ West' :
                             rest.zone === 'EAST' ? '🍵 East' :
                             rest.zone === 'CENTRAL' ? '🌾 Rural / Central' : 
                             rest.zone === 'DYNAMIC' ? '🌾 Dynamic Cluster' : '📍 Pan-India'}
                          </span>
                          <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-orange-50 text-orange-800">
                            {rest.typeLabel}
                          </span>
                          <h3 className="text-xl font-black text-slate-900">{rest.name}</h3>
                          <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Star className="w-3 h-3 fill-emerald-600" /> {rest.rating}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">{rest.tagline}</p>
                        <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-3 flex-wrap">
                          <span>🍽️ {rest.cuisine}</span>
                          <span>📍 {rest.hubLocation || rest.distance}</span>
                          <span>⏱️ ~{rest.prepTimeMinutes} mins prep</span>
                          <span className="font-bold text-amber-600 font-mono">({rest.menu.length} items available)</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedStore(rest)}
                      className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-sm transition-all"
                    >
                      <span>View All {rest.menu.length} Items</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Highlights / Sample 3 dishes preview */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-6">
                    {rest.menu.slice(0, 3).map(dish => {
                      const qty = cart[dish.id]?.quantity || 0;

                      return (
                        <div 
                          key={dish.id}
                          className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 flex flex-col justify-between hover:shadow-md transition-all"
                        >
                          <div>
                            <div className="h-36 w-full rounded-xl overflow-hidden bg-slate-200 mb-3 relative">
                              <img src={dish.image} alt={dish.name} className="w-full h-full object-cover" />
                              <div className="absolute top-2 left-2 bg-white/95 px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 shadow-sm">
                                <span className={`w-2 h-2 rounded-full ${dish.isVeg ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                                {dish.isVeg ? 'Veg' : 'Non-Veg'}
                              </div>
                              <div className="absolute top-2 right-2 bg-slate-900/80 text-white px-2 py-0.5 rounded text-[10px] font-bold">
                                {dish.category}
                              </div>
                            </div>

                            <div className="flex justify-between items-start gap-2">
                              <h4 className="font-bold text-sm text-slate-900 leading-snug">{dish.name}</h4>
                              <span className="font-mono font-black text-slate-900 text-sm">₹{dish.price}</span>
                            </div>
                            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                              {dish.description}
                            </p>
                          </div>

                          <div className="mt-4 pt-2">
                            {qty === 0 ? (
                              <button
                                onClick={() => addToCart(dish)}
                                className="w-full bg-slate-900 hover:bg-black text-white font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                              >
                                <Plus className="w-3.5 h-3.5 text-amber-400" />
                                Add to OmniCart
                              </button>
                            ) : (
                              <div className="flex items-center justify-between bg-white border border-slate-300 rounded-xl p-1">
                                <button
                                  onClick={() => removeFromCart(dish.id)}
                                  className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold flex items-center justify-center"
                                >
                                  <Minus className="w-3.5 h-3.5" />
                                </button>
                                <span className="font-bold font-mono text-sm text-slate-900">{qty}</span>
                                <button
                                  onClick={() => addToCart(dish)}
                                  className="w-8 h-8 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold flex items-center justify-center shadow-sm"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {rest.menu.length > 3 && (
                    <div className="mt-4 text-center">
                      <button
                        onClick={() => setSelectedStore(rest)}
                        className="text-xs font-bold text-amber-700 hover:text-amber-800 underline inline-flex items-center gap-1"
                      >
                        + View {rest.menu.length - 3} more items in {rest.name}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Floating Bottom OmniCart Bar */}
      {cartItems.length > 0 && !isCartOpen && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-full max-w-xl px-4 z-40">
          <div 
            onClick={() => setIsCartOpen(true)}
            className="bg-slate-900 text-white rounded-2xl p-4 shadow-2xl flex items-center justify-between cursor-pointer hover:bg-black transition-all border border-slate-700"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold text-sm">
                  {cartItems.reduce((a, b) => a + b.quantity, 0)} Items from {uniqueRestaurants.length} Outlets
                </div>
                <div className="text-[11px] text-emerald-400 font-semibold">
                  🎉 Saving ₹{deliverySavings} on delivery fees vs Swiggy!
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="font-mono font-extrabold text-base">₹{grandTotal}</span>
              <span className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1">
                View Cart <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Cross-Store Multi-Cart Checkout Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-end">
          <div className="bg-white w-full max-w-lg h-full flex flex-col shadow-2xl p-6 overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div>
                <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-amber-600" />
                  Your Cross-Store OmniCart
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Combined order from {uniqueRestaurants.length} outlets in 1 delivery
                </p>
              </div>
              <button onClick={() => setIsCartOpen(false)} className="p-1 text-slate-400 hover:text-slate-800 text-lg font-bold">
                ✕
              </button>
            </div>

            {cartItems.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-400 py-20">
                <ShoppingBag className="w-12 h-12 mb-3 stroke-1" />
                <p className="font-bold text-slate-600">Your OmniCart is empty</p>
                <p className="text-xs text-slate-400 mt-1">Add food from multiple stores to combine them!</p>
              </div>
            ) : (
              <form onSubmit={handleCheckout} className="flex-1 flex flex-col justify-between mt-4">
                <div className="space-y-4">
                  {/* Items Grouped by Store */}
                  <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                    {uniqueRestaurants.map(restName => {
                      const restItems = cartItems.filter(c => c.item.restaurantName === restName);

                      return (
                        <div key={restName} className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2">
                          <div className="text-xs font-black text-slate-800 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
                            <Store className="w-3.5 h-3.5 text-amber-600" />
                            <span>{restName}</span>
                          </div>

                          {restItems.map(({ item, quantity }) => (
                            <div key={item.id} className="flex justify-between items-center text-xs">
                              <div>
                                <span className="font-semibold text-slate-800">{item.name}</span>
                                <div className="text-[11px] text-slate-400 font-mono">₹{item.price} each</div>
                              </div>
                              <div className="flex items-center gap-2">
                                <button type="button" onClick={() => removeFromCart(item.id)} className="p-1 rounded bg-white border border-slate-200">
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="font-bold font-mono text-slate-900">{quantity}</span>
                                <button type="button" onClick={() => addToCart(item)} className="p-1 rounded bg-white border border-slate-200">
                                  <Plus className="w-3 h-3" />
                                </button>
                                <span className="font-bold font-mono text-slate-900 w-12 text-right">
                                  ₹{item.price * quantity}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      );
                    })}
                  </div>

                  {/* Swiggy Comparison vs OmniCart Savings Box */}
                  <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-300 rounded-2xl p-4 text-xs space-y-1.5">
                    <div className="font-extrabold text-emerald-900 flex items-center gap-1.5">
                      <TrendingDown className="w-4 h-4 text-emerald-600" />
                      Why OmniCart is Superior to Swiggy/Zomato:
                    </div>
                    <div className="flex justify-between text-slate-600 pt-1">
                      <span>Swiggy Delivery Fees ({uniqueRestaurants.length} separate orders):</span>
                      <span className="line-through text-rose-600 font-mono">₹{swiggyDeliveryEquivalent}</span>
                    </div>
                    <div className="flex justify-between text-emerald-800 font-bold">
                      <span>OmniCart Combined Route Fee (1 Rider):</span>
                      <span className="font-mono">₹{multiStopDeliveryFee}</span>
                    </div>
                    <div className="text-[11px] font-black text-emerald-700 border-t border-emerald-200 pt-1 mt-1">
                      🎉 Instant Customer Savings: ₹{deliverySavings} Saved!
                    </div>
                  </div>

                  {/* Delivery Address */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Customer Delivery Address
                    </h4>
                    <div>
                      <input 
                        type="text" required value={name} onChange={e => setName(e.target.value)}
                        placeholder="Your Full Name"
                        className="w-full text-xs p-2 rounded-lg border border-slate-300 mb-2 focus:outline-amber-500" 
                      />
                      <input 
                        type="text" required value={phone} onChange={e => setPhone(e.target.value)}
                        placeholder="Phone Number"
                        className="w-full text-xs p-2 rounded-lg border border-slate-300 mb-2 focus:outline-amber-500" 
                      />
                      <textarea 
                        rows={2} required value={address} onChange={e => setAddress(e.target.value)}
                        placeholder="Full Delivery Address"
                        className="w-full text-xs p-2 rounded-lg border border-slate-300 focus:outline-amber-500" 
                      />
                    </div>
                  </div>

                  {/* Summary */}
                  <div className="bg-slate-100 p-3.5 rounded-2xl text-xs space-y-1.5 font-mono">
                    <div className="flex justify-between text-slate-600">
                      <span>Items Total ({cartItems.length} items)</span>
                      <span>₹{itemsTotal}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>GST (5%)</span>
                      <span>₹{taxes}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Multi-Stop Consolidated Delivery</span>
                      <span>₹{multiStopDeliveryFee}</span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-900 border-t border-slate-200 pt-1.5 text-base">
                      <span>Grand Total</span>
                      <span>₹{grandTotal}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full bg-amber-600 hover:bg-amber-700 text-white font-extrabold py-3.5 rounded-2xl text-sm flex items-center justify-center gap-2 shadow-lg transition-colors"
                  >
                    <span>{submitting ? 'Routing Multi-Stop Order...' : `Place OmniCart Order (₹${grandTotal})`}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className="text-[11px] text-center text-slate-400 mt-2">
                    1 Rider • Combined Delivery • Dual Thermal Bag
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
