import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { 
  TrendingUp, DollarSign, Percent, ShoppingBag, 
  Award, PieChart, RefreshCw, AlertCircle 
} from 'lucide-react';

export default function AnalyticsDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchAnalytics = async () => {
    try {
      const res = await api.getAnalyticsSummary();
      if (res.success) setData(res.summary);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center p-20 text-slate-400">
        <RefreshCw className="w-6 h-6 animate-spin text-indigo-600 mr-2" />
        <span>Loading financial ledger...</span>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="flex-1 bg-slate-50 min-h-screen p-6 space-y-6">
      {/* Title */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">
            Channel Analytics & Commission Reconciliation
          </h1>
          <p className="text-xs text-slate-500">
            Financial comparison between direct high-margin orders vs aggregator marketplace commissions
          </p>
        </div>
        <button
          onClick={fetchAnalytics}
          className="px-4 py-2 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-1.5 shadow-sm"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh Metrics
        </button>
      </div>

      {/* Top 4 KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Gross GMV</span>
            <DollarSign className="w-5 h-5 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            ₹{data.grossRevenue.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Across all order channels</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-rose-200 shadow-sm bg-rose-50/20">
          <div className="flex items-center justify-between text-rose-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Aggregator Cut</span>
            <Percent className="w-5 h-5" />
          </div>
          <div className="text-2xl font-black text-rose-600 font-mono">
            -₹{data.totalCommissionPaid.toLocaleString()}
          </div>
          <div className="text-[11px] text-rose-600/80 mt-1">Paid to Swiggy (22%) & Zomato (24%)</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-emerald-200 shadow-sm bg-emerald-50/20">
          <div className="flex items-center justify-between text-emerald-600 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Net Restaurant Payout</span>
            <TrendingUp className="w-5 h-5" />
          </div>
          <div className="text-2xl font-black text-emerald-700 font-mono">
            ₹{data.netRestaurantPayout.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600/80 mt-1">Retained bank settlement</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Volume</span>
            <ShoppingBag className="w-5 h-5 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {data.totalOrders} Orders
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Completed & in-flight tickets</div>
        </div>
      </div>

      {/* Channel Comparison Section */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <h2 className="text-base font-bold text-slate-900 mb-4">
          Channel Breakdown: Marketplace vs Direct Ordering Margin
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Direct */}
          <div className="p-4 rounded-xl border-2 border-emerald-300 bg-emerald-50/30">
            <div className="flex items-center justify-between mb-2">
              <span className="font-extrabold text-sm text-emerald-800">🌐 Direct Website / PWA</span>
              <span className="text-xs font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                0% Commission
              </span>
            </div>
            <div className="text-xl font-black text-slate-900 font-mono mt-2">
              ₹{data.channelMetrics?.DIRECT?.gross || 0}
            </div>
            <div className="text-xs text-slate-500 mt-0.5">{data.channelMetrics?.DIRECT?.count || 0} orders</div>

            <div className="mt-4 pt-3 border-t border-emerald-200 text-xs space-y-1">
              <div className="flex justify-between text-slate-600">
                <span>Commission Deducted:</span>
                <span className="font-bold text-emerald-700">₹0 (Saved!)</span>
              </div>
              <div className="flex justify-between font-bold text-slate-900">
                <span>Net Retained Margin:</span>
                <span className="text-emerald-700 font-mono">100%</span>
              </div>
            </div>
          </div>

          {/* Swiggy */}
          <div className="p-4 rounded-xl border-2 border-orange-300 bg-orange-50/30">
            <div className="flex items-center justify-between mb-2">
              <span className="font-extrabold text-sm text-[#FC8019]">🟠 Swiggy Aggregator</span>
              <span className="text-xs font-bold bg-orange-100 text-orange-800 px-2 py-0.5 rounded-full">
                22% Take Rate
              </span>
            </div>
            <div className="text-xl font-black text-slate-900 font-mono mt-2">
              ₹{data.channelMetrics?.SWIGGY?.gross || 0}
            </div>
            <div className="text-xs text-slate-500 mt-0.5">{data.channelMetrics?.SWIGGY?.count || 0} orders</div>

            <div className="mt-4 pt-3 border-t border-orange-200 text-xs space-y-1">
              <div className="flex justify-between text-slate-600">
                <span>Commission Deducted:</span>
                <span className="font-bold text-rose-600 font-mono">-₹{data.channelMetrics?.SWIGGY?.commission || 0}</span>
              </div>
              <div className="flex justify-between font-bold text-slate-900">
                <span>Net Payout:</span>
                <span className="text-slate-900 font-mono">₹{data.channelMetrics?.SWIGGY?.net || 0}</span>
              </div>
            </div>
          </div>

          {/* Zomato */}
          <div className="p-4 rounded-xl border-2 border-rose-300 bg-rose-50/30">
            <div className="flex items-center justify-between mb-2">
              <span className="font-extrabold text-sm text-[#E23744]">🔴 Zomato Aggregator</span>
              <span className="text-xs font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full">
                24% Take Rate
              </span>
            </div>
            <div className="text-xl font-black text-slate-900 font-mono mt-2">
              ₹{data.channelMetrics?.ZOMATO?.gross || 0}
            </div>
            <div className="text-xs text-slate-500 mt-0.5">{data.channelMetrics?.ZOMATO?.count || 0} orders</div>

            <div className="mt-4 pt-3 border-t border-rose-200 text-xs space-y-1">
              <div className="flex justify-between text-slate-600">
                <span>Commission Deducted:</span>
                <span className="font-bold text-rose-600 font-mono">-₹{data.channelMetrics?.ZOMATO?.commission || 0}</span>
              </div>
              <div className="flex justify-between font-bold text-slate-900">
                <span>Net Payout:</span>
                <span className="text-slate-900 font-mono">₹{data.channelMetrics?.ZOMATO?.net || 0}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Sellers and Order Pipeline */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top 5 Dishes */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-slate-900 text-base">Top Selling Dishes</h3>
          </div>
          <div className="space-y-3">
            {data.topDishes?.map((dish, i) => (
              <div key={i} className="flex items-center justify-between text-xs pb-2 border-b border-slate-100 last:border-b-0">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center font-mono">
                    #{i + 1}
                  </span>
                  <span className="font-semibold text-slate-800">{dish.name}</span>
                </div>
                <span className="font-bold font-mono text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-md">
                  {dish.count} ordered
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Pipeline Distribution */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center gap-2 mb-4">
            <PieChart className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-base">Order Fulfillment Pipeline</h3>
          </div>
          <div className="space-y-2.5 text-xs">
            {Object.entries(data.statusCounts || {}).map(([st, cnt]) => (
              <div key={st} className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                <span className="font-semibold text-slate-700">{st.replace('_', ' ')}</span>
                <span className="font-mono font-bold text-slate-900 bg-white px-2.5 py-0.5 rounded shadow-sm">
                  {cnt}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
