import React, { useState, useEffect } from 'react';
import { api, socket } from '../services/api';
import { playNewOrderChime } from '../utils/audio';
import { 
  Bell, CheckCircle2, Clock, AlertCircle, ChefHat, 
  Bike, Printer, DollarSign, RefreshCw, X, ShieldAlert 
} from 'lucide-react';

export default function PosTerminal() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [channelFilter, setChannelFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedReceipt, setSelectedReceipt] = useState(null);
  const [audioEnabled, setAudioEnabled] = useState(true);

  const fetchOrders = async () => {
    try {
      const data = await api.getOrders();
      if (data.success) {
        setOrders(data.orders);
      }
    } catch (err) {
      console.error('Failed to fetch orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();

    // Socket listeners
    const handleNewOrder = (payload) => {
      console.log('New order received on POS:', payload);
      if (audioEnabled) {
        playNewOrderChime();
      }
      setOrders(prev => [payload.order, ...prev.filter(o => o.id !== payload.order.id)]);
    };

    const handleStatusUpdated = (payload) => {
      setOrders(prev => prev.map(o => (o.id === payload.orderId || o.orderNumber === payload.orderNumber) ? payload.order : o));
    };

    const handleRiderUpdated = (payload) => {
      setOrders(prev => prev.map(o => (o.id === payload.orderId || o.orderNumber === payload.orderNumber) ? { ...o, rider: payload.rider } : o));
    };

    socket.on('new_order', handleNewOrder);
    socket.on('order_status_updated', handleStatusUpdated);
    socket.on('rider_status_updated', handleRiderUpdated);

    return () => {
      socket.off('new_order', handleNewOrder);
      socket.off('order_status_updated', handleStatusUpdated);
      socket.off('rider_status_updated', handleRiderUpdated);
    };
  }, [audioEnabled]);

  const handleUpdateStatus = async (orderId, newStatus, extra = {}) => {
    try {
      const res = await api.updateOrderStatus(orderId, newStatus, extra);
      if (res.success) {
        setOrders(prev => prev.map(o => o.id === orderId ? res.order : o));
      }
    } catch (err) {
      alert(`Error updating order: ${err.message}`);
    }
  };

  const filteredOrders = orders.filter(ord => {
    if (channelFilter !== 'ALL' && ord.channel !== channelFilter) return false;
    if (statusFilter !== 'ALL' && ord.status !== statusFilter) return false;
    return true;
  });

  const placedCount = orders.filter(o => o.status === 'PLACED').length;
  const kitchenCount = orders.filter(o => o.status === 'IN_KITCHEN' || o.status === 'ACCEPTED').length;
  const readyCount = orders.filter(o => o.status === 'FOOD_READY').length;

  return (
    <div className="flex flex-col flex-1 bg-slate-100 min-h-screen">
      {/* POS Top Bar */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-indigo-100">
            POS
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 leading-tight">Live Order & Dispatch Terminal</h1>
            <p className="text-xs text-slate-500">Omnichannel order feed with automatic aggregator reconciliation</p>
          </div>
        </div>

        {/* Status Pills */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setAudioEnabled(!audioEnabled)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              audioEnabled ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-slate-200 text-slate-600'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            {audioEnabled ? 'Sound Chime: ON' : 'Sound Chime: MUTED'}
          </button>

          <button 
            onClick={fetchOrders}
            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
            title="Refresh Orders"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Control Filters */}
      <div className="px-6 py-3 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-sm">
        {/* Channel Filter */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-1">Channel:</span>
          {['ALL', 'DIRECT', 'SWIGGY', 'ZOMATO'].map(ch => (
            <button
              key={ch}
              onClick={() => setChannelFilter(ch)}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                channelFilter === ch 
                  ? ch === 'SWIGGY' ? 'bg-[#FC8019] text-white shadow-sm'
                    : ch === 'ZOMATO' ? 'bg-[#E23744] text-white shadow-sm'
                    : ch === 'DIRECT' ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {ch === 'DIRECT' ? '🌐 Direct Web' : ch === 'SWIGGY' ? '🟠 Swiggy' : ch === 'ZOMATO' ? '🔴 Zomato' : 'All Channels'}
            </button>
          ))}
        </div>

        {/* Status Stage Filter */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-1">Stage:</span>
          {[
            { id: 'ALL', label: 'All' },
            { id: 'PLACED', label: `New (${placedCount})`, highlight: placedCount > 0 },
            { id: 'IN_KITCHEN', label: `Kitchen (${kitchenCount})` },
            { id: 'FOOD_READY', label: `Ready (${readyCount})` },
            { id: 'DELIVERED', label: 'Delivered' }
          ].map(st => (
            <button
              key={st.id}
              onClick={() => setStatusFilter(st.id)}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                statusFilter === st.id
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : st.highlight
                    ? 'bg-rose-100 text-rose-700 font-bold border border-rose-300 animate-pulse'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>
      </div>

      {/* Orders Grid */}
      <div className="p-6 overflow-y-auto flex-1">
        {loading ? (
          <div className="flex items-center justify-center py-20 text-slate-400">
            <RefreshCw className="w-8 h-8 animate-spin text-indigo-500" />
            <span className="ml-3 font-medium">Loading live order stream...</span>
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300">
            <div className="w-14 h-14 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3 text-slate-400">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold text-slate-700">No active orders in this filter</h3>
            <p className="text-sm text-slate-500 mt-1">Simulate a Swiggy or Zomato order or place a direct order to see it live here!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredOrders.map(order => {
              const isNew = order.status === 'PLACED';
              const isSwiggy = order.channel === 'SWIGGY';
              const isZomato = order.channel === 'ZOMATO';
              const isDirect = order.channel === 'DIRECT';

              return (
                <div 
                  key={order.id}
                  className={`bg-white rounded-2xl border transition-all shadow-sm flex flex-col justify-between overflow-hidden ${
                    isNew 
                      ? 'border-amber-400 ring-2 ring-amber-300 shadow-md animate-ring-pulse' 
                      : order.status === 'FOOD_READY'
                        ? 'border-emerald-300'
                        : 'border-slate-200 hover:shadow-md'
                  }`}
                >
                  {/* Card Header */}
                  <div className={`p-4 border-b flex items-start justify-between ${
                    isSwiggy ? 'bg-[#FFF6F0] border-orange-100' :
                    isZomato ? 'bg-[#FFF0F2] border-rose-100' :
                    'bg-[#F0FDF4] border-emerald-100'
                  }`}>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-0.5 rounded-md text-xs font-black uppercase tracking-wide flex items-center gap-1 ${
                          isSwiggy ? 'bg-[#FC8019] text-white' :
                          isZomato ? 'bg-[#E23744] text-white' :
                          'bg-emerald-600 text-white'
                        }`}>
                          {isSwiggy ? '🟠 SWIGGY' : isZomato ? '🔴 ZOMATO' : '🌐 DIRECT WEB'}
                        </span>
                        <span className="font-extrabold text-slate-900 text-base">{order.orderNumber}</span>
                        {order.orderType === 'PICKUP' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-400 text-slate-950 flex items-center gap-1">
                            🛍️ PICKUP {order.pickupCode ? `(${order.pickupCode})` : ''}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500 mt-1 font-mono">
                        {order.channelOrderId ? `ID: ${order.channelOrderId}` : ''}
                      </div>
                    </div>

                    {/* Status Badge */}
                    <div className="text-right">
                      <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        order.status === 'PLACED' ? 'bg-amber-100 text-amber-800' :
                        order.status === 'ACCEPTED' ? 'bg-blue-100 text-blue-800' :
                        order.status === 'IN_KITCHEN' ? 'bg-indigo-100 text-indigo-800' :
                        order.status === 'FOOD_READY' ? 'bg-emerald-100 text-emerald-800' :
                        order.status === 'OUT_FOR_DELIVERY' ? 'bg-purple-100 text-purple-800' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {order.status.replace('_', ' ')}
                      </span>
                      <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-end gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>

                  {/* Customer & Location */}
                  <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-100 text-xs text-slate-600 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-slate-800">{order.customer?.name}</span>
                      <span className="text-slate-400 mx-1">•</span>
                      <span>{order.customer?.phone}</span>
                    </div>
                    <button 
                      onClick={() => setSelectedReceipt(order)}
                      className="text-slate-500 hover:text-indigo-600 flex items-center gap-1 font-semibold"
                      title="View KOT / Bill"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      KOT
                    </button>
                  </div>

                  {/* Items List */}
                  <div className="p-4 flex-1 space-y-2">
                    {order.items?.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-start text-xs text-slate-700 border-b border-slate-100 pb-1.5 last:border-b-0">
                        <div className="flex items-start gap-2">
                          <span className="font-bold text-slate-900 bg-slate-100 rounded px-1.5 py-0.5">
                            {item.quantity}x
                          </span>
                          <div>
                            <div className="font-semibold text-slate-800">{item.name}</div>
                            {item.addOns && item.addOns.length > 0 && (
                              <div className="text-[11px] text-indigo-600 font-medium">
                                + {item.addOns.join(', ')}
                              </div>
                            )}
                            {item.notes && (
                              <div className="text-[11px] text-amber-600 italic">
                                Note: {item.notes}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="font-semibold text-slate-900">
                          ₹{item.totalPrice}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Rider Status Strip */}
                  <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 text-xs flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <Bike className="w-4 h-4 text-slate-500" />
                      <span className="truncate max-w-[180px]">
                        {order.rider?.name || 'No rider assigned'}
                      </span>
                    </div>
                    {order.rider?.status === 'ARRIVED_AT_STORE' ? (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full animate-bounce">
                        RIDER ARRIVED
                      </span>
                    ) : (
                      <span className="text-[10px] font-medium text-slate-500">
                        {order.rider?.status || 'UNASSIGNED'}
                      </span>
                    )}
                  </div>

                  {/* Financial & Commission Strip */}
                  <div className="px-4 py-2 bg-slate-100 text-xs flex items-center justify-between font-mono">
                    <div className="text-slate-600">
                      Total: <span className="font-bold text-slate-900">₹{order.financials?.grandTotal}</span>
                    </div>
                    {order.financials?.platformCommissionAmount > 0 ? (
                      <div className="text-rose-700 text-[11px]">
                        Comm ({Math.round(order.financials.platformCommissionRate * 100)}%): -₹{order.financials.platformCommissionAmount} | Net: <span className="font-bold text-emerald-700">₹{order.financials.netRestaurantPayout}</span>
                      </div>
                    ) : (
                      <div className="text-emerald-700 font-bold text-[11px]">
                        Net (100% Payout): ₹{order.financials?.netRestaurantPayout}
                      </div>
                    )}
                  </div>

                  {/* Cashier Action Buttons */}
                  <div className="p-3 bg-white border-t border-slate-200">
                    {order.status === 'PLACED' && (
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-bold text-amber-700 uppercase tracking-wider text-center">
                          🔔 Incoming Order - Accept with Prep Time:
                        </div>
                        <div className="grid grid-cols-3 gap-1.5">
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'ACCEPTED', { prepTimeMinutes: 15 })}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg text-xs shadow-sm transition-colors"
                          >
                            Accept 15m
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'ACCEPTED', { prepTimeMinutes: 20 })}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg text-xs shadow-sm transition-colors"
                          >
                            Accept 20m
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'ACCEPTED', { prepTimeMinutes: 30 })}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg text-xs shadow-sm transition-colors"
                          >
                            Accept 30m
                          </button>
                        </div>
                      </div>
                    )}

                    {order.status === 'ACCEPTED' && (
                      <button
                        onClick={() => handleUpdateStatus(order.id, 'IN_KITCHEN')}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                      >
                        <ChefHat className="w-4 h-4" />
                        Send to Kitchen Display (KDS)
                      </button>
                    )}

                    {order.status === 'IN_KITCHEN' && (
                      <button
                        onClick={() => handleUpdateStatus(order.id, 'FOOD_READY')}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        Mark Food Ready & Packed
                      </button>
                    )}

                    {order.status === 'FOOD_READY' && (
                      order.orderType === 'PICKUP' ? (
                        <button
                          onClick={() => handleUpdateStatus(order.id, 'DELIVERED', { actor: 'COUNTER_STAFF', notes: 'Handed over directly to customer at pickup counter' })}
                          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          Handover to Customer (Self-Pickup Complete)
                        </button>
                      ) : (
                        <button
                          onClick={() => handleUpdateStatus(order.id, 'OUT_FOR_DELIVERY')}
                          className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                        >
                          <Bike className="w-4 h-4" />
                          Handover to Rider & Dispatch
                        </button>
                      )
                    )}

                    {order.status === 'OUT_FOR_DELIVERY' && (
                      <button
                        onClick={() => handleUpdateStatus(order.id, 'DELIVERED')}
                        className="w-full bg-slate-800 hover:bg-black text-white font-bold py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        Mark Delivered (Complete)
                      </button>
                    )}

                    {order.status === 'DELIVERED' && (
                      <div className="text-center py-1 text-xs font-bold text-emerald-700 flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        Order Fulfilled & Closed
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal: KOT / Bill Receipt */}
      {selectedReceipt && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative font-mono text-slate-800 text-xs">
            <button 
              onClick={() => setSelectedReceipt(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-800 p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center border-b border-dashed border-slate-300 pb-3 mb-3">
              <h2 className="text-base font-bold text-slate-900 font-sans">SPICE GARDEN RESTAURANT</h2>
              <p className="text-[11px] text-slate-500">KITCHEN ORDER TICKET (KOT) / RECEIPT</p>
              <div className="mt-1 font-bold text-sm bg-slate-100 py-1 rounded">
                ORDER {selectedReceipt.orderNumber} ({selectedReceipt.channel})
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                {new Date(selectedReceipt.createdAt).toLocaleString()}
              </div>
            </div>

            <div className="mb-3 space-y-1">
              <div><strong>Customer:</strong> {selectedReceipt.customer?.name}</div>
              <div><strong>Phone:</strong> {selectedReceipt.customer?.phone}</div>
              <div className="truncate"><strong>Address:</strong> {selectedReceipt.customer?.address}</div>
              {selectedReceipt.channelOrderId && (
                <div><strong>Channel Ref:</strong> {selectedReceipt.channelOrderId}</div>
              )}
            </div>

            <div className="border-t border-b border-dashed border-slate-300 py-2 my-2">
              <div className="font-bold flex justify-between mb-1 text-[11px]">
                <span>ITEM</span>
                <span>QTY x RATE</span>
                <span>AMT</span>
              </div>
              {selectedReceipt.items?.map((it, i) => (
                <div key={i} className="flex justify-between py-0.5">
                  <span className="truncate max-w-[170px]">{it.name}</span>
                  <span>{it.quantity} x {it.unitPrice}</span>
                  <span>₹{it.totalPrice}</span>
                </div>
              ))}
            </div>

            <div className="space-y-1 text-right text-[11px]">
              <div>Item Subtotal: ₹{selectedReceipt.financials?.itemTotal}</div>
              <div>Taxes (GST 5%): ₹{selectedReceipt.financials?.taxes}</div>
              <div>Delivery Fee: ₹{selectedReceipt.financials?.deliveryFee}</div>
              <div className="text-sm font-bold text-slate-900 border-t border-slate-200 pt-1">
                Grand Total: ₹{selectedReceipt.financials?.grandTotal}
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <button 
                onClick={() => window.print()} 
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-sans font-bold py-2 rounded-lg text-xs"
              >
                Print Ticket
              </button>
              <button 
                onClick={() => setSelectedReceipt(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-sans font-semibold rounded-lg text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
