import React, { useState, useEffect } from 'react';
import { api, socket } from '../services/api';
import { ChefHat, Clock, CheckCircle2, AlertTriangle, Flame, RefreshCw } from 'lucide-react';

export default function KitchenDisplay() {
  const [orders, setOrders] = useState([]);
  const [currentTime, setCurrentTime] = useState(new Date());

  const fetchKitchenOrders = async () => {
    try {
      const data = await api.getOrders();
      if (data.success) {
        // Kitchen only cares about orders needing preparation
        setOrders(data.orders.filter(o => 
          o.status === 'ACCEPTED' || 
          o.status === 'IN_KITCHEN' || 
          o.status === 'PLACED'
        ));
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchKitchenOrders();

    const timer = setInterval(() => setCurrentTime(new Date()), 1000);

    const handleNewOrder = (payload) => {
      setOrders(prev => [payload.order, ...prev.filter(o => o.id !== payload.order.id)]);
    };

    const handleStatusUpdated = (payload) => {
      if (['FOOD_READY', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED'].includes(payload.newStatus)) {
        setOrders(prev => prev.filter(o => o.id !== payload.orderId && o.orderNumber !== payload.orderNumber));
      } else {
        setOrders(prev => prev.map(o => (o.id === payload.orderId || o.orderNumber === payload.orderNumber) ? payload.order : o));
      }
    };

    const handleItemUpdated = ({ orderId, itemIndex, itemStatus }) => {
      setOrders(prev => prev.map(o => {
        if (o.id === orderId) {
          const newItems = [...o.items];
          if (newItems[itemIndex]) newItems[itemIndex].kitchenItemStatus = itemStatus;
          return { ...o, items: newItems };
        }
        return o;
      }));
    };

    socket.on('new_order', handleNewOrder);
    socket.on('order_status_updated', handleStatusUpdated);
    socket.on('kds_item_updated', handleItemUpdated);

    return () => {
      clearInterval(timer);
      socket.off('new_order', handleNewOrder);
      socket.off('order_status_updated', handleStatusUpdated);
      socket.off('kds_item_updated', handleItemUpdated);
    };
  }, []);

  const handleBumpOrder = async (orderId) => {
    try {
      await api.updateOrderStatus(orderId, 'FOOD_READY', { actor: 'CHEF_KDS' });
      setOrders(prev => prev.filter(o => o.id !== orderId));
    } catch (err) {
      alert(`Error bumping ticket: ${err.message}`);
    }
  };

  const handleToggleItemStatus = async (orderId, itemIndex, currentStatus) => {
    const nextStatus = currentStatus === 'READY' ? 'PENDING' : 'READY';
    try {
      await api.updateItemStatus(orderId, itemIndex, nextStatus);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="flex flex-col flex-1 bg-slate-950 text-white min-h-screen">
      {/* KDS Header Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
            <ChefHat className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-wide text-white uppercase">
              Kitchen Display System (KDS)
            </h1>
            <p className="text-xs text-slate-400">Real-time prep station order tickets</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="bg-slate-800 px-4 py-2 rounded-xl border border-slate-700 text-right">
            <div className="text-xs text-slate-400 font-mono">ACTIVE TICKETS</div>
            <div className="text-2xl font-black text-amber-400 font-mono leading-none mt-0.5">
              {orders.length}
            </div>
          </div>

          <div className="text-right font-mono">
            <div className="text-2xl font-extrabold text-white">
              {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </div>
            <div className="text-xs text-slate-400">
              {currentTime.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}
            </div>
          </div>
        </div>
      </div>

      {/* Tickets Board */}
      <div className="p-6 flex-1 overflow-x-auto">
        {orders.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center py-28 text-center text-slate-500">
            <div className="w-16 h-16 rounded-full bg-slate-900 flex items-center justify-center mb-4 text-emerald-500 border border-slate-800">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-slate-300">Kitchen Queue Clear!</h3>
            <p className="text-sm text-slate-500 max-w-sm mt-1">All orders have been prepared and packed. Waiting for new customer orders...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {orders.map(order => {
              const elapsedMinutes = Math.floor((currentTime - new Date(order.createdAt)) / 60000);
              const isOverdue = elapsedMinutes > 20;
              const isWarning = elapsedMinutes > 12;

              const isSwiggy = order.channel === 'SWIGGY';
              const isZomato = order.channel === 'ZOMATO';

              const allItemsReady = order.items && order.items.every(it => it.kitchenItemStatus === 'READY');

              return (
                <div 
                  key={order.id}
                  className={`bg-slate-900 rounded-2xl border-2 flex flex-col justify-between overflow-hidden shadow-xl transition-all ${
                    isOverdue 
                      ? 'border-rose-600 bg-rose-950/20' 
                      : isWarning 
                        ? 'border-amber-500 bg-amber-950/10' 
                        : 'border-slate-800'
                  }`}
                >
                  {/* Ticket Header */}
                  <div className={`p-3.5 border-b flex items-center justify-between ${
                    isOverdue ? 'bg-rose-900/60 border-rose-700' :
                    isWarning ? 'bg-amber-900/50 border-amber-700' :
                    'bg-slate-800/80 border-slate-700'
                  }`}>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-black uppercase tracking-wider ${
                          isSwiggy ? 'bg-[#FC8019] text-white' :
                          isZomato ? 'bg-[#E23744] text-white' :
                          'bg-emerald-600 text-white'
                        }`}>
                          {order.channel}
                        </span>
                        <span className="font-mono text-lg font-black text-white">{order.orderNumber}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        Target: {order.prepTimeMinutes || 20} min
                      </div>
                    </div>

                    {/* Elapsed Time Ticker */}
                    <div className={`px-2.5 py-1 rounded-lg font-mono text-xs font-black flex items-center gap-1.5 ${
                      isOverdue ? 'bg-rose-600 text-white animate-pulse' :
                      isWarning ? 'bg-amber-500 text-slate-950' :
                      'bg-slate-800 text-emerald-400 border border-slate-700'
                    }`}>
                      <Clock className="w-3.5 h-3.5" />
                      {elapsedMinutes}m elapsed
                    </div>
                  </div>

                  {/* Customer / Rider indicator */}
                  <div className="px-3.5 py-1.5 bg-slate-950/60 border-b border-slate-800 text-xs text-slate-400 flex justify-between">
                    <span>{order.customer?.name}</span>
                    <span className="font-mono">{order.items?.length || 0} items</span>
                  </div>

                  {/* Dish List with click-to-strike */}
                  <div className="p-3.5 flex-1 space-y-2.5 overflow-y-auto max-h-60">
                    {order.items?.map((item, idx) => {
                      const isReady = item.kitchenItemStatus === 'READY';

                      return (
                        <div 
                          key={idx}
                          onClick={() => handleToggleItemStatus(order.id, idx, item.kitchenItemStatus)}
                          className={`p-2.5 rounded-xl border cursor-pointer select-none transition-all ${
                            isReady 
                              ? 'bg-slate-950/80 border-emerald-900/60 opacity-50 line-through text-slate-500' 
                              : 'bg-slate-800/80 border-slate-700 hover:border-amber-400 text-white'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-start gap-2.5">
                              <span className={`px-2 py-0.5 rounded font-mono text-sm font-black ${
                                isReady ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-500 text-slate-950'
                              }`}>
                                {item.quantity}x
                              </span>
                              <div>
                                <div className="text-sm font-bold leading-tight">{item.name}</div>
                                {item.addOns && item.addOns.length > 0 && (
                                  <div className="text-xs text-amber-400 font-mono mt-0.5">
                                    + {item.addOns.join(', ')}
                                  </div>
                                )}
                                {item.notes && (
                                  <div className="text-xs text-rose-400 italic mt-0.5">
                                    Chef Note: {item.notes}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="mt-0.5">
                              {isReady ? (
                                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                              ) : (
                                <div className="w-5 h-5 rounded-full border border-slate-600 hover:border-amber-400" />
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* KDS Action: Bump Ticket */}
                  <div className="p-3 bg-slate-950 border-t border-slate-800">
                    <button
                      onClick={() => handleBumpOrder(order.id)}
                      className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 uppercase tracking-wider transition-all shadow-lg ${
                        allItemsReady 
                          ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 ring-4 ring-emerald-500/30' 
                          : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                      }`}
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      {allItemsReady ? 'All Prepared - Bump Ticket' : 'Bump Ticket (Ready & Packed)'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
