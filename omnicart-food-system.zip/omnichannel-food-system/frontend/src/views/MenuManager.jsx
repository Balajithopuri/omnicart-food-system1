import React, { useState, useEffect } from 'react';
import { api, socket } from '../services/api';
import { Utensils, CheckCircle2, XCircle, RefreshCw, Zap } from 'lucide-react';

export default function MenuManager() {
  const [menu, setMenu] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncStatusMessage, setSyncStatusMessage] = useState(null);

  const fetchMenu = async () => {
    try {
      const res = await api.getMenu();
      if (res.success) setMenu(res.items);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMenu();

    const handleInventorySync = (payload) => {
      setMenu(prev => prev.map(item => 
        item.id === payload.item.id ? { ...item, isAvailable: payload.isAvailable } : item
      ));
      setSyncStatusMessage(`Live Sync: "${payload.item.name}" availability updated across Direct, Swiggy, and Zomato`);
      setTimeout(() => setSyncStatusMessage(null), 4000);
    };

    socket.on('inventory_synced', handleInventorySync);

    return () => {
      socket.off('inventory_synced', handleInventorySync);
    };
  }, []);

  const handleToggle = async (item) => {
    const nextAvailability = !item.isAvailable;
    try {
      const res = await api.toggleItemAvailability(item.id, nextAvailability);
      if (res.success) {
        setMenu(prev => prev.map(i => i.id === item.id ? { ...i, isAvailable: nextAvailability } : i));
        setSyncStatusMessage(`Item "${item.name}" updated to ${nextAvailability ? 'AVAILABLE' : '86-ED (OUT OF STOCK)'}. Broadcasted to Swiggy & Zomato.`);
        setTimeout(() => setSyncStatusMessage(null), 4000);
      }
    } catch (err) {
      alert(`Error toggling item: ${err.message}`);
    }
  };

  return (
    <div className="flex-1 bg-slate-50 min-h-screen p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900">
            Catalog & Live Inventory (86-ing Control)
          </h1>
          <p className="text-xs text-slate-500">
            Toggle item availability here to instantly update your Direct website, Swiggy menu, and Zomato catalog in real-time.
          </p>
        </div>

        <button
          onClick={fetchMenu}
          className="px-4 py-2 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-1.5 shadow-sm"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh Catalog
        </button>
      </div>

      {syncStatusMessage && (
        <div className="bg-indigo-600 text-white px-4 py-3 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg animate-fade-in">
          <Zap className="w-4 h-4 text-amber-300" />
          <span>{syncStatusMessage}</span>
        </div>
      )}

      {/* Menu Table / Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-600 font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Dish Details</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Price</th>
                <th className="py-3.5 px-4">Aggregator Mapping IDs</th>
                <th className="py-3.5 px-4">Status & Sync</th>
                <th className="py-3.5 px-4 text-right">86-ing Toggle</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {menu.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 flex items-center gap-3">
                    <img 
                      src={item.imageUrl} 
                      alt={item.name} 
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                    />
                    <div>
                      <div className="font-bold text-slate-900 text-sm">{item.name}</div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <span className={`w-2 h-2 rounded-full ${item.isVeg ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                        <span>{item.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-600">
                    {item.category}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">
                    ₹{item.price}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] space-y-0.5">
                    <div className="text-[#FC8019]">Swiggy: {item.swiggyItemId}</div>
                    <div className="text-[#E23744]">Zomato: {item.zomatoItemId}</div>
                  </td>
                  <td className="py-3 px-4">
                    {item.isAvailable ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        In Stock (All Channels)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full font-bold">
                        <XCircle className="w-3.5 h-3.5" />
                        86-ed (Disabled)
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleToggle(item)}
                      className={`px-3.5 py-1.5 rounded-xl font-bold text-xs transition-all shadow-sm ${
                        item.isAvailable
                          ? 'bg-rose-100 hover:bg-rose-200 text-rose-800'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      }`}
                    >
                      {item.isAvailable ? 'Mark Out of Stock' : 'Mark In Stock'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
