import React, { useState, useEffect } from 'react';
import { api, socket } from '../services/api';
import { 
  Send, RefreshCw, Eye, CheckCircle2, ShieldCheck, 
  Terminal, ArrowRight, Zap, Bike, AlertCircle, Code 
} from 'lucide-react';

export default function AggregatorSimulator() {
  const [logs, setLogs] = useState([]);
  const [selectedLog, setSelectedLog] = useState(null);
  const [swiggyCustomer, setSwiggyCustomer] = useState('Rahul Nair');
  const [zomatoCustomer, setZomatoCustomer] = useState('Ananya Sen');
  const [loadingAction, setLoadingAction] = useState(null);
  const [activeOrders, setActiveOrders] = useState([]);

  const fetchLogs = async () => {
    try {
      const res = await api.getSimulatorLogs();
      if (res.success) setLogs(res.logs);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchActiveOrders = async () => {
    try {
      const res = await api.getOrders();
      if (res.success) {
        setActiveOrders(res.orders.filter(o => o.channel !== 'DIRECT' && o.status !== 'DELIVERED'));
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchLogs();
    fetchActiveOrders();

    const handleNewOrder = () => {
      fetchLogs();
      fetchActiveOrders();
    };

    const handleSyncEvent = () => {
      fetchLogs();
    };

    socket.on('new_order', handleNewOrder);
    socket.on('aggregator_sync_event', handleSyncEvent);
    socket.on('inventory_synced', handleSyncEvent);

    return () => {
      socket.off('new_order', handleNewOrder);
      socket.off('aggregator_sync_event', handleSyncEvent);
      socket.off('inventory_synced', handleSyncEvent);
    };
  }, []);

  const triggerOrder = async (channel, name) => {
    setLoadingAction(`order-${channel}`);
    try {
      const res = await api.triggerSimulatedOrder(channel, name);
      if (res.success) {
        await fetchLogs();
        await fetchActiveOrders();
        // Select the newly generated log for inspection
        if (logs.length > 0) setSelectedLog(res);
      }
    } catch (err) {
      alert(`Simulation error: ${err.message}`);
    } finally {
      setLoadingAction(null);
    }
  };

  const triggerRiderArrival = async (orderId) => {
    if (!orderId) return;
    setLoadingAction(`rider-${orderId}`);
    try {
      const res = await api.triggerRiderArrival(orderId);
      if (res.success) {
        await fetchActiveOrders();
        await fetchLogs();
      }
    } catch (err) {
      alert(`Error triggering rider arrival: ${err.message}`);
    } finally {
      setLoadingAction(null);
    }
  };

  return (
    <div className="flex-1 bg-slate-100 min-h-screen p-6 flex flex-col gap-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold mb-2">
            <Zap className="w-3.5 h-3.5" />
            Major Project Evaluator Sandbox
          </div>
          <h1 className="text-2xl font-black text-slate-900 leading-tight">
            Swiggy & Zomato Aggregator Simulator Hub
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            This module emulates external food aggregator partner webhooks, testing real-time ingestion, payload normalization via the Adapter Pattern, and two-way status synchronization.
          </p>
        </div>

        <button 
          onClick={() => { fetchLogs(); fetchActiveOrders(); }}
          className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          Refresh Stream
        </button>
      </div>

      {/* Aggregator Sandbox Terminals Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Swiggy Simulator Box */}
        <div className="bg-white rounded-2xl border-2 border-orange-200 shadow-sm overflow-hidden flex flex-col justify-between">
          <div className="bg-[#FFF6F0] p-4 border-b border-orange-100 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-xl bg-[#FC8019] text-white font-black text-base flex items-center justify-center shadow-md shadow-orange-200">
                S
              </span>
              <div>
                <h3 className="font-extrabold text-slate-900 text-base">Swiggy Partner Sandbox</h3>
                <span className="text-[11px] text-[#FC8019] font-semibold">Endpoint: /api/webhooks/swiggy</span>
              </div>
            </div>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Webhook Active
            </span>
          </div>

          <div className="p-5 space-y-4">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
              <div className="flex justify-between">
                <span>Platform Commission Rate:</span>
                <span className="font-bold text-slate-900 font-mono">22% flat</span>
              </div>
              <div className="flex justify-between">
                <span>Payload Standard:</span>
                <span className="font-bold text-slate-900 font-mono">Swiggy Merchant v2.1</span>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                Simulated Customer Name
              </label>
              <input
                type="text"
                value={swiggyCustomer}
                onChange={e => setSwiggyCustomer(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-[#FC8019]"
                placeholder="Customer Name..."
              />
            </div>

            <button
              onClick={() => triggerOrder('SWIGGY', swiggyCustomer)}
              disabled={loadingAction === 'order-SWIGGY'}
              className="w-full bg-[#FC8019] hover:bg-[#E26D0E] text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-orange-100 transition-colors"
            >
              <Send className="w-4 h-4" />
              <span>{loadingAction === 'order-SWIGGY' ? 'Injecting Webhook...' : 'Dispatch Simulated Swiggy Order'}</span>
            </button>
          </div>
        </div>

        {/* Zomato Simulator Box */}
        <div className="bg-white rounded-2xl border-2 border-rose-200 shadow-sm overflow-hidden flex flex-col justify-between">
          <div className="bg-[#FFF0F2] p-4 border-b border-rose-100 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-xl bg-[#E23744] text-white font-black text-base flex items-center justify-center shadow-md shadow-rose-200">
                Z
              </span>
              <div>
                <h3 className="font-extrabold text-slate-900 text-base">Zomato Partner Sandbox</h3>
                <span className="text-[11px] text-[#E23744] font-semibold">Endpoint: /api/webhooks/zomato</span>
              </div>
            </div>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Webhook Active
            </span>
          </div>

          <div className="p-5 space-y-4">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
              <div className="flex justify-between">
                <span>Platform Commission Rate:</span>
                <span className="font-bold text-slate-900 font-mono">24% flat</span>
              </div>
              <div className="flex justify-between">
                <span>Payload Standard:</span>
                <span className="font-bold text-slate-900 font-mono">Zomato Restaurant Ingestion</span>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                Simulated Customer Name
              </label>
              <input
                type="text"
                value={zomatoCustomer}
                onChange={e => setZomatoCustomer(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-[#E23744]"
                placeholder="Customer Name..."
              />
            </div>

            <button
              onClick={() => triggerOrder('ZOMATO', zomatoCustomer)}
              disabled={loadingAction === 'order-ZOMATO'}
              className="w-full bg-[#E23744] hover:bg-[#CB202D] text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-rose-100 transition-colors"
            >
              <Send className="w-4 h-4" />
              <span>{loadingAction === 'order-ZOMATO' ? 'Injecting Webhook...' : 'Dispatch Simulated Zomato Order'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mid-Strip: Quick Rider Status Trigger */}
      {activeOrders.length > 0 && (
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Bike className="w-4 h-4 text-indigo-600" />
            Simulate Aggregator Rider Arrival at Restaurant (In-Store Pickup)
          </h3>
          <div className="flex flex-wrap gap-3">
            {activeOrders.map(order => (
              <button
                key={order.id}
                onClick={() => triggerRiderArrival(order.id)}
                disabled={loadingAction === `rider-${order.id}` || order.rider?.status === 'ARRIVED_AT_STORE'}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all ${
                  order.rider?.status === 'ARRIVED_AT_STORE'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800 opacity-60 cursor-not-allowed'
                    : order.channel === 'SWIGGY'
                      ? 'bg-orange-50 border-orange-300 text-orange-900 hover:bg-orange-100'
                      : 'bg-rose-50 border-rose-300 text-rose-900 hover:bg-rose-100'
                }`}
              >
                <span>{order.channel === 'SWIGGY' ? '🟠' : '🔴'}</span>
                <span>{order.orderNumber} ({order.customer?.name})</span>
                <span className="font-bold text-[10px] uppercase ml-1">
                  {order.rider?.status === 'ARRIVED_AT_STORE' ? '✓ Arrived' : 'Trigger Arrival'}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Webhook Audit Stream & Payload Inspector */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-indigo-600" />
            <h2 className="text-base font-bold text-slate-900">
              Aggregator Webhook Audit Log & Payload Inspector
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {logs.length} logged webhook events
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Logs List */}
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {logs.length === 0 ? (
              <div className="text-center py-12 text-slate-400 text-xs">
                No webhook logs recorded yet. Click Dispatch above to simulate an event.
              </div>
            ) : (
              logs.map((log, idx) => {
                const isSwiggy = log.source === 'SWIGGY';
                const isZomato = log.source === 'ZOMATO';

                return (
                  <div
                    key={log.id || idx}
                    onClick={() => setSelectedLog(log)}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                      selectedLog?.id === log.id 
                        ? 'border-indigo-600 bg-indigo-50/50 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded font-black text-[10px] text-white ${
                          isSwiggy ? 'bg-[#FC8019]' : isZomato ? 'bg-[#E23744]' : 'bg-slate-700'
                        }`}>
                          {log.source}
                        </span>
                        <span className="font-bold text-slate-900">{log.eventType}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(log.createdAt).toLocaleTimeString()}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Ref: {log.channelOrderId || 'N/A'}</span>
                      <span className="text-emerald-600 font-semibold">{log.status}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* JSON Inspector */}
          <div className="bg-slate-950 rounded-2xl p-4 text-emerald-400 font-mono text-xs overflow-auto max-h-96 border border-slate-800">
            {selectedLog ? (
              <div>
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800 text-slate-400 text-[11px]">
                  <span>EVENT: {selectedLog.eventType} ({selectedLog.source})</span>
                  <span>LATENCY: {selectedLog.processingLatencyMs || 25}ms</span>
                </div>
                <div className="mb-2 text-slate-400 text-[11px] font-bold uppercase tracking-wider">
                  Raw Partner Webhook Ingested Payload:
                </div>
                <pre className="text-slate-300 text-[11px] leading-relaxed whitespace-pre-wrap mb-4 bg-slate-900 p-3 rounded-lg overflow-x-auto">
                  {JSON.stringify(selectedLog.payload, null, 2)}
                </pre>

                {selectedLog.normalizedUnifiedOrder && (
                  <>
                    <div className="mb-2 text-indigo-400 text-[11px] font-bold uppercase tracking-wider">
                      Normalized UnifiedOrder Object (Adapter Output):
                    </div>
                    <pre className="text-indigo-200 text-[11px] leading-relaxed whitespace-pre-wrap bg-slate-900 p-3 rounded-lg overflow-x-auto">
                      {JSON.stringify(selectedLog.normalizedUnifiedOrder, null, 2)}
                    </pre>
                  </>
                )}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-600 py-20 text-center">
                <Code className="w-8 h-8 mb-2" />
                <p>Click on any log event on the left to inspect raw payloads and adapter transformations.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
