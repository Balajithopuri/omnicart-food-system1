/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        swiggy: {
          DEFAULT: '#FC8019',
          dark: '#E26D0E',
          light: '#FFF1E8'
        },
        zomato: {
          DEFAULT: '#E23744',
          dark: '#CB202D',
          light: '#FDECEE'
        },
        direct: {
          DEFAULT: '#10B981',
          dark: '#059669',
          light: '#ECFDF5'
        }
      }
    },
  },
  plugins: [],
}
